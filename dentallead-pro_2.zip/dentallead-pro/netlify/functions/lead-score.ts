import type { Handler } from "@netlify/functions";

/**
 * Standalone Netlify Function: recompute a lead score from raw signals.
 * Demonstrates server-side operations separate from Next.js route handlers.
 *
 * Invoke (mapped via netlify.toml redirect):
 *   POST /api/functions/lead-score
 *   body: { num_locations, num_dentists, website, facebook_url, ... }
 */
interface Signals {
  num_locations?: number;
  num_dentists?: number;
  website?: string | null;
  facebook_url?: string | null;
  instagram_url?: string | null;
  linkedin_url?: string | null;
  email?: string | null;
  phone?: string | null;
}

function score(s: Signals): number {
  let v = 30;
  v += Math.min(s.num_locations ?? 1, 5) * 7;
  v += Math.min(s.num_dentists ?? 1, 12);
  if (s.website) v += 8;
  if (s.facebook_url) v += 5;
  if (s.instagram_url) v += 5;
  if (s.linkedin_url) v += 7;
  if (s.email) v += 6;
  if (s.phone) v += 4;
  return Math.max(20, Math.min(99, Math.round(v)));
}

export const handler: Handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  try {
    const signals = JSON.parse(event.body ?? "{}") as Signals;
    return {
      statusCode: 200,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ score: score(signals) }),
    };
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
};
