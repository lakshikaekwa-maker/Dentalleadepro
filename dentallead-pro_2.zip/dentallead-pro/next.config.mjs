/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [],
  },
  eslint: {
    // Lint is run separately in CI; don't fail the Netlify build on lint.
    ignoreDuringBuilds: true,
  },
};

export default nextConfig;
