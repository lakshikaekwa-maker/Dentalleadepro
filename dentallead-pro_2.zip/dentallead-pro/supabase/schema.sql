-- ===========================================================================
-- DentalLead Pro — Supabase schema
-- Run this in: Supabase Dashboard → SQL Editor → New query → Run.
-- Safe to re-run (uses IF NOT EXISTS / CREATE OR REPLACE).
-- ===========================================================================

-- Extensions ----------------------------------------------------------------
create extension if not exists "pgcrypto";  -- for gen_random_uuid()

-- updated_at trigger function -----------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ===========================================================================
-- leads
-- ===========================================================================
create table if not exists public.leads (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references auth.users (id) on delete cascade,
  practice_name      text not null,
  contact_name       text,
  job_title          text,
  website            text,
  facebook_url       text,
  instagram_url      text,
  linkedin_url       text,
  email              text,
  phone              text,
  state              text,
  city               text,
  num_locations      integer not null default 1 check (num_locations >= 0),
  num_dentists       integer not null default 1 check (num_dentists  >= 0),
  specialty          text,
  source             text not null default 'Other',
  score              integer not null default 50 check (score between 0 and 100),
  status             text not null default 'New',
  notes              text,
  last_contact_date  date,
  next_followup_date date,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create index if not exists leads_user_id_idx          on public.leads (user_id);
create index if not exists leads_status_idx           on public.leads (user_id, status);
create index if not exists leads_state_idx            on public.leads (user_id, state);
create index if not exists leads_source_idx           on public.leads (user_id, source);
create index if not exists leads_followup_idx         on public.leads (user_id, next_followup_date);

drop trigger if exists leads_set_updated_at on public.leads;
create trigger leads_set_updated_at
  before update on public.leads
  for each row execute function public.set_updated_at();

-- ===========================================================================
-- activities (timeline / contact log per lead)
-- ===========================================================================
create table if not exists public.activities (
  id         uuid primary key default gen_random_uuid(),
  lead_id    uuid not null references public.leads (id) on delete cascade,
  user_id    uuid not null references auth.users (id) on delete cascade,
  message    text not null,
  kind       text not null default 'log',
  created_at timestamptz not null default now()
);

create index if not exists activities_lead_id_idx on public.activities (lead_id);
create index if not exists activities_user_id_idx on public.activities (user_id);

-- ===========================================================================
-- Row Level Security — each user can only see/modify their own rows
-- ===========================================================================
alter table public.leads      enable row level security;
alter table public.activities enable row level security;

drop policy if exists "leads owner select" on public.leads;
drop policy if exists "leads owner insert" on public.leads;
drop policy if exists "leads owner update" on public.leads;
drop policy if exists "leads owner delete" on public.leads;

create policy "leads owner select" on public.leads
  for select using (auth.uid() = user_id);
create policy "leads owner insert" on public.leads
  for insert with check (auth.uid() = user_id);
create policy "leads owner update" on public.leads
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "leads owner delete" on public.leads
  for delete using (auth.uid() = user_id);

drop policy if exists "activities owner select" on public.activities;
drop policy if exists "activities owner insert" on public.activities;
drop policy if exists "activities owner delete" on public.activities;

create policy "activities owner select" on public.activities
  for select using (auth.uid() = user_id);
create policy "activities owner insert" on public.activities
  for insert with check (auth.uid() = user_id);
create policy "activities owner delete" on public.activities
  for delete using (auth.uid() = user_id);
