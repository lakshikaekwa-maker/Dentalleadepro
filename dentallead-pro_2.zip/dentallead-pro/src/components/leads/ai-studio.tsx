"use client";

import { useState } from "react";
import { Sparkles, Loader2, Copy, Check } from "lucide-react";
import { AI_ACTION_LABELS } from "@/lib/ai";
import type { AiAction, Lead } from "@/types";

const ACTIONS: AiAction[] = [
  "analyze",
  "outreach_email",
  "linkedin_message",
  "facebook_message",
  "followup_email",
  "score_recommendation",
];

export function AiStudio({ lead }: { lead: Lead }) {
  const [loading, setLoading] = useState<AiAction | null>(null);
  const [result, setResult] = useState<{ action: AiAction; text: string } | null>(null);
  const [copied, setCopied] = useState(false);

  async function run(action: AiAction) {
    setLoading(action);
    setResult(null);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action, lead }),
      });
      const data = (await res.json()) as { text?: string; error?: string };
      setResult({ action, text: data.text ?? data.error ?? "No response." });
    } catch {
      setResult({ action, text: "Request failed. Please try again." });
    } finally {
      setLoading(null);
    }
  }

  function copy() {
    if (!result) return;
    navigator.clipboard?.writeText(result.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  }

  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <Sparkles size={16} color="var(--accent)" />
        <b className="text-sm">AI Studio</b>
      </div>
      <div className="mb-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        {ACTIONS.map((a) => (
          <button
            key={a}
            disabled={!!loading}
            onClick={() => run(a)}
            className="btn justify-start rounded-[10px] px-3 py-2.5 text-left text-[12.5px]"
            style={{
              background: result?.action === a ? "var(--accent)22" : "var(--input-bg)",
              color: result?.action === a ? "var(--accent)" : "var(--text)",
              border: "1px solid var(--border)",
            }}
          >
            {loading === a ? (
              <Loader2 size={14} className="spin" />
            ) : (
              <Sparkles size={14} color="var(--accent)" />
            )}
            {AI_ACTION_LABELS[a]}
          </button>
        ))}
      </div>

      {result && (
        <div className="card p-4" style={{ background: "var(--input-bg)" }}>
          <div className="mb-2.5 flex items-center justify-between">
            <b className="text-[13px]" style={{ color: "var(--accent)" }}>
              {AI_ACTION_LABELS[result.action]}
            </b>
            <button
              className="btn rounded-lg px-2.5 py-1.5 text-xs"
              style={{ background: "var(--surface)", color: copied ? "var(--accent2)" : "var(--sub)", border: "1px solid var(--border)" }}
              onClick={copy}
            >
              {copied ? <Check size={13} /> : <Copy size={13} />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
          <pre className="whitespace-pre-wrap font-sans text-[12.8px] leading-relaxed" style={{ margin: 0 }}>
            {result.text}
          </pre>
        </div>
      )}
      {!result && !loading && (
        <div className="py-5 text-center text-[12.5px]" style={{ color: "var(--sub)" }}>
          Pick an action to generate AI content for this lead.
        </div>
      )}
    </div>
  );
}
