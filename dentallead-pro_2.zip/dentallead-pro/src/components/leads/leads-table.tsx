"use client";

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  Edit3,
  AlertTriangle,
} from "lucide-react";
import {
  LEAD_STATUSES,
  LEAD_SOURCES,
  SPECIALTIES,
  STAGE_COLORS,
  SOURCE_COLORS,
  type Lead,
} from "@/types";
import { scoreColor, formatDate, daysUntil, findDuplicateIds } from "@/lib/utils";
import { exportCsv, exportExcel, csvToLeads } from "@/lib/csv";
import { bulkImportLeads } from "@/app/leads/actions";
import { LeadModal } from "./lead-modal";

interface Filters {
  state: string;
  specialty: string;
  status: string;
  source: string;
  minLoc: string;
  minScore: string;
}

const EMPTY_FILTERS: Filters = {
  state: "",
  specialty: "",
  status: "",
  source: "",
  minLoc: "",
  minScore: "",
};

export function LeadsTable({ leads }: { leads: Lead[] }) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [editing, setEditing] = useState<Lead | "new" | null>(null);
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const dupes = useMemo(() => findDuplicateIds(leads), [leads]);
  const states = useMemo(
    () => [...new Set(leads.map((l) => l.state).filter(Boolean))].sort() as string[],
    [leads],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return leads.filter((l) => {
      if (
        q &&
        !`${l.practice_name} ${l.contact_name ?? ""} ${l.email ?? ""} ${l.city ?? ""} ${l.state ?? ""}`
          .toLowerCase()
          .includes(q)
      )
        return false;
      if (filters.state && l.state !== filters.state) return false;
      if (filters.specialty && l.specialty !== filters.specialty) return false;
      if (filters.status && l.status !== filters.status) return false;
      if (filters.source && l.source !== filters.source) return false;
      if (filters.minLoc && l.num_locations < Number(filters.minLoc)) return false;
      if (filters.minScore && l.score < Number(filters.minScore)) return false;
      return true;
    });
  }, [leads, query, filters]);

  const activeFilters = Object.values(filters).filter(Boolean).length;

  async function handleImport(file: File) {
    const text = await file.text();
    const parsed = csvToLeads(text);
    if (parsed.length === 0) {
      setImportMsg("No valid rows found in CSV.");
      return;
    }
    const res = await bulkImportLeads(parsed);
    setImportMsg(`Imported ${res.inserted} leads (${res.skipped} skipped as duplicates).`);
    router.refresh();
  }

  return (
    <div>
      <div className="mb-3.5 flex flex-wrap items-center gap-2.5">
        <div className="relative min-w-[160px] flex-1 sm:max-w-[360px]">
          <Search size={16} className="absolute left-3 top-[11px]" style={{ color: "var(--sub)" }} />
          <input
            className="input pl-9"
            placeholder="Search practices, contacts, cities…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <button
          className="btn rounded-[10px] px-3.5 py-[9px] text-sm"
          style={{
            background: showFilters ? "var(--accent)22" : "var(--input-bg)",
            color: showFilters ? "var(--accent)" : "var(--text)",
            border: "1px solid var(--border)",
          }}
          onClick={() => setShowFilters((s) => !s)}
        >
          <Filter size={15} />
          Filters
          {activeFilters > 0 && (
            <span className="chip" style={{ background: "var(--accent)", color: "#04121a" }}>
              {activeFilters}
            </span>
          )}
        </button>
        <div className="ml-auto flex flex-wrap gap-2">
          <button
            className="btn rounded-[10px] px-3 py-[9px] text-sm"
            style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
            onClick={() => fileRef.current?.click()}
          >
            <Upload size={15} /> Import CSV
          </button>
          <button
            className="btn rounded-[10px] px-3 py-[9px] text-sm"
            style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
            onClick={() => exportCsv(filtered)}
          >
            <Download size={15} /> CSV
          </button>
          <button
            className="btn rounded-[10px] px-3 py-[9px] text-sm"
            style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
            onClick={() => exportExcel(filtered)}
          >
            <Download size={15} /> Excel
          </button>
          <button
            className="btn rounded-[10px] px-4 py-2.5 text-sm font-bold"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))", color: "#04121a" }}
            onClick={() => setEditing("new")}
          >
            <Plus size={16} /> Add Lead
          </button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleImport(f);
            e.target.value = "";
          }}
        />
      </div>

      {importMsg && (
        <div
          className="mb-3 rounded-[10px] px-3 py-2 text-xs font-medium"
          style={{ background: "var(--accent2)22", color: "var(--accent2)" }}
        >
          {importMsg}
        </div>
      )}

      {showFilters && (
        <div className="card mb-3.5 grid grid-cols-2 gap-3 p-4 sm:grid-cols-3 lg:grid-cols-4">
          <Select label="State" value={filters.state} onChange={(v) => setFilters((f) => ({ ...f, state: v }))} options={states} />
          <Select label="Specialty" value={filters.specialty} onChange={(v) => setFilters((f) => ({ ...f, specialty: v }))} options={[...SPECIALTIES]} />
          <Select label="Status" value={filters.status} onChange={(v) => setFilters((f) => ({ ...f, status: v }))} options={[...LEAD_STATUSES]} />
          <Select label="Source" value={filters.source} onChange={(v) => setFilters((f) => ({ ...f, source: v }))} options={[...LEAD_SOURCES]} />
          <div>
            <label className="text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Min Locations</label>
            <input className="input" type="number" value={filters.minLoc} onChange={(e) => setFilters((f) => ({ ...f, minLoc: e.target.value }))} placeholder="any" />
          </div>
          <div>
            <label className="text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Min Score</label>
            <input className="input" type="number" value={filters.minScore} onChange={(e) => setFilters((f) => ({ ...f, minScore: e.target.value }))} placeholder="any" />
          </div>
          <div className="flex items-end">
            <button
              className="btn rounded-[10px] px-4 py-2.5 text-sm"
              style={{ background: "var(--input-bg)", color: "var(--sub)", border: "1px solid var(--border)" }}
              onClick={() => setFilters(EMPTY_FILTERS)}
            >
              Clear all
            </button>
          </div>
        </div>
      )}

      <div className="mb-2 flex items-center gap-3 text-sm" style={{ color: "var(--sub)" }}>
        <span>{filtered.length} of {leads.length} leads</span>
        {dupes.size > 0 && (
          <span className="chip flex items-center gap-1" style={{ background: "#f8717122", color: "#f87171" }}>
            <AlertTriangle size={12} /> {dupes.size} possible duplicates
          </span>
        )}
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse text-[13.5px]">
            <thead>
              <tr className="text-left text-[11.5px] uppercase tracking-wide" style={{ color: "var(--sub)" }}>
                {["Practice", "Contact", "Location", "Score", "Source", "Status", "Next Follow-Up", ""].map((h) => (
                  <th key={h} className="px-3.5 py-3 font-bold" style={{ borderBottom: "1px solid var(--border)" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => {
                const days = daysUntil(l.next_followup_date);
                return (
                  <tr
                    key={l.id}
                    className="row-hover cursor-pointer"
                    onClick={() => router.push(`/leads/${l.id}`)}
                  >
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <div className="flex items-center gap-1.5 font-bold">
                        {l.practice_name}
                        {dupes.has(l.id) && <AlertTriangle size={13} color="#f87171" />}
                      </div>
                      <div className="text-[11.5px]" style={{ color: "var(--sub)" }}>
                        {l.specialty} · {l.num_locations} loc
                      </div>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <div className="font-semibold">{l.contact_name ?? "—"}</div>
                      <div className="text-[11.5px]" style={{ color: "var(--sub)" }}>{l.job_title ?? ""}</div>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)", color: "var(--sub)" }}>
                      {[l.city, l.state].filter(Boolean).join(", ") || "—"}
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="chip" style={{ background: `${scoreColor(l.score)}22`, color: scoreColor(l.score) }}>
                        {l.score}
                      </span>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="inline-flex items-center gap-1.5 text-[12.5px]">
                        <span className="h-2 w-2 rounded" style={{ background: SOURCE_COLORS[l.source] }} />
                        {l.source}
                      </span>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="chip" style={{ background: `${STAGE_COLORS[l.status]}22`, color: STAGE_COLORS[l.status] }}>
                        {l.status}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-[12.5px]" style={{ borderBottom: "1px solid var(--border)", color: "var(--sub)" }}>
                      {l.next_followup_date ? (
                        <span
                          style={{
                            color: days !== null && days < 0 ? "#f87171" : days === 0 ? "#fbbf24" : "var(--sub)",
                            fontWeight: days !== null && days <= 0 ? 700 : 400,
                          }}
                        >
                          {days !== null && days < 0 ? `${-days}d overdue` : days === 0 ? "Today" : formatDate(l.next_followup_date)}
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-3.5 py-3 text-right" style={{ borderBottom: "1px solid var(--border)" }}>
                      <button
                        className="btn p-1.5"
                        style={{ background: "transparent", color: "var(--sub)" }}
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditing(l);
                        }}
                      >
                        <Edit3 size={15} />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-10 text-center" style={{ color: "var(--sub)" }}>
                    No leads match your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <LeadModal
          lead={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <label className="text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>{label}</label>
      <select className="input cursor-pointer" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">All</option>
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}
