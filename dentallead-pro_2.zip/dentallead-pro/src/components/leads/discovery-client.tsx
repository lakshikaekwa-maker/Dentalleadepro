"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Radar,
  Search,
  Loader2,
  Info,
  Layers,
  Globe,
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  Phone,
  Building2,
  Wand2,
  Copy,
  Plus,
  PlusCircle,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { SPECIALTIES } from "@/types";
import { scoreColor, dedupeKey } from "@/lib/utils";
import {
  US_STATES,
  discoverPractices,
  outreachFor,
  type DiscoveredLead,
} from "@/lib/discovery";
import { bulkImportLeads } from "@/app/leads/actions";

export function DiscoveryClient({ existingKeys }: { existingKeys: string[] }) {
  const router = useRouter();
  const [state, setState] = useState("CA");
  const [specialty, setSpecialty] = useState("All Specialties");
  const [minLoc, setMinLoc] = useState(1);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<DiscoveredLead[] | null>(null);
  const [saved, setSaved] = useState<Record<string, "added" | "duplicate">>({});
  const [openMsg, setOpenMsg] = useState<string | null>(null);

  const knownSet = useMemo(() => new Set(existingKeys), [existingKeys]);
  const isKnown = (p: DiscoveredLead) =>
    knownSet.has(dedupeKey({ email: p.email, practice_name: p.practice_name }));

  function runSearch() {
    setLoading(true);
    setResults(null);
    setSaved({});
    // Simulates extraction latency; swap discoverPractices for a real API call.
    setTimeout(() => {
      setResults(discoverPractices({ state, specialty, minLocations: minLoc }));
      setLoading(false);
    }, 800);
  }

  async function saveOne(p: DiscoveredLead) {
    const { discoveryId, ...input } = p;
    const res = await bulkImportLeads([input]);
    setSaved((s) => ({ ...s, [discoveryId]: res.inserted > 0 ? "added" : "duplicate" }));
    router.refresh();
  }

  async function saveAll() {
    if (!results) return;
    const toSave = results.filter((p) => !saved[p.discoveryId] && !isKnown(p));
    if (toSave.length === 0) return;
    const inputs = toSave.map(({ discoveryId, ...rest }) => rest);
    const res = await bulkImportLeads(inputs);
    const next = { ...saved };
    // Mark as added optimistically; duplicates within the batch are skipped server-side.
    toSave.forEach((p, idx) => {
      next[p.discoveryId] = idx < res.inserted ? "added" : "duplicate";
    });
    setSaved(next);
    router.refresh();
  }

  const newCount = results
    ? results.filter((p) => !saved[p.discoveryId] && !isKnown(p)).length
    : 0;
  const multiCount = results ? results.filter((p) => p.num_locations > 1).length : 0;

  return (
    <div>
      <div
        className="card mb-4 p-5"
        style={{ background: "linear-gradient(135deg, var(--accent)10, transparent)" }}
      >
        <div className="mb-1 flex items-center gap-2.5">
          <div className="grid h-[34px] w-[34px] place-items-center rounded-[10px]" style={{ background: "var(--accent)22" }}>
            <Radar size={18} color="var(--accent)" />
          </div>
          <div>
            <h2 className="font-display text-[17px] font-extrabold">Discover New Leads</h2>
            <div className="text-[12.5px]" style={{ color: "var(--sub)" }}>
              Find dental practices from public business listings &amp; social profiles.
            </div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>U.S. State</label>
            <select className="input cursor-pointer" value={state} onChange={(e) => setState(e.target.value)}>
              {US_STATES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Specialty</label>
            <select className="input cursor-pointer" value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
              <option>All Specialties</option>
              {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Min Locations</label>
            <input className="input" type="number" min={1} value={minLoc} onChange={(e) => setMinLoc(Number(e.target.value) || 1)} />
          </div>
          <div className="flex items-end">
            <button
              className="btn w-full justify-center rounded-[10px] py-2.5 text-sm font-bold"
              style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))", color: "#04121a", height: 42 }}
              onClick={runSearch}
              disabled={loading}
            >
              {loading ? <Loader2 size={17} className="spin" /> : <Search size={16} />}
              {loading ? "Searching…" : "Discover"}
            </button>
          </div>
        </div>
      </div>

      <div
        className="mb-4 flex items-start gap-2.5 rounded-[11px] border px-3.5 py-2.5 text-xs leading-relaxed"
        style={{ background: "var(--input-bg)", borderColor: "var(--border)", color: "var(--sub)" }}
      >
        <Info size={15} color="var(--accent)" className="mt-0.5 flex-shrink-0" />
        <span>
          Results are compiled from public business information. In this build they’re generated locally to
          illustrate the workflow — connect a directory/social API in production. Always confirm contact
          details and respect opt-out / anti-spam rules before outreach.
        </span>
      </div>

      {loading && (
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="card p-4 opacity-50">
              <div className="mb-2.5 h-3.5 w-3/5 rounded-md" style={{ background: "var(--border)" }} />
              <div className="mb-4 h-2.5 w-2/5 rounded-md" style={{ background: "var(--border)" }} />
              <div className="mb-2 h-2.5 w-11/12 rounded-md" style={{ background: "var(--border)" }} />
              <div className="h-2.5 w-3/4 rounded-md" style={{ background: "var(--border)" }} />
            </div>
          ))}
        </div>
      )}

      {results && !loading && (
        <div>
          <div className="mb-3.5 flex flex-wrap items-center gap-3">
            <div className="text-sm font-bold">{results.length} practices found</div>
            <span className="chip flex items-center gap-1" style={{ background: "var(--accent2)22", color: "var(--accent2)" }}>
              <Layers size={12} /> {multiCount} multi-location
            </span>
            <span className="chip" style={{ background: "var(--accent)22", color: "var(--accent)" }}>{newCount} new to CRM</span>
            <button
              className="btn ml-auto rounded-[10px] px-4 py-2.5 text-sm font-bold"
              disabled={newCount === 0}
              onClick={saveAll}
              style={{
                background: newCount ? "linear-gradient(135deg, var(--accent), var(--accent2))" : "var(--input-bg)",
                color: newCount ? "#04121a" : "var(--sub)",
              }}
            >
              <PlusCircle size={15} /> Save all new ({newCount})
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 xl:grid-cols-3">
            {results.map((p) => {
              const stateMark = saved[p.discoveryId];
              const known = isKnown(p);
              const done = stateMark === "added";
              const dup = stateMark === "duplicate" || known;
              return (
                <div
                  key={p.discoveryId}
                  className="card flex flex-col gap-2.5 p-4"
                  style={{ borderTop: `3px solid ${scoreColor(p.score)}` }}
                >
                  <div className="flex justify-between gap-2.5">
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[14.5px] font-extrabold">
                        {p.practice_name}
                        {p.num_locations > 1 && (
                          <span className="chip inline-flex items-center gap-1" style={{ background: "var(--accent2)22", color: "var(--accent2)" }}>
                            <Layers size={10} /> {p.num_locations} locations
                          </span>
                        )}
                      </div>
                      <div className="mt-0.5 text-xs" style={{ color: "var(--sub)" }}>
                        {p.specialty} · {p.city}, {p.state}
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-center">
                      <div className="grid h-[42px] w-[42px] place-items-center rounded-[11px]" style={{ background: `${scoreColor(p.score)}22` }}>
                        <span className="font-display text-base font-extrabold" style={{ color: scoreColor(p.score) }}>{p.score}</span>
                      </div>
                      <div className="mt-0.5 text-[9.5px] font-semibold" style={{ color: "var(--sub)" }}>SCORE</div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1 text-[12.5px]" style={{ color: "var(--sub)" }}>
                    <span className="flex items-center gap-1.5"><Building2 size={13} />{p.contact_name} · {p.num_dentists} dentist{p.num_dentists > 1 ? "s" : ""}</span>
                    {p.email && <span className="flex items-center gap-1.5"><Mail size={13} />{p.email}</span>}
                    {p.phone && <span className="flex items-center gap-1.5"><Phone size={13} />{p.phone}</span>}
                  </div>

                  <div className="flex items-center gap-3.5 pt-0.5">
                    <a href={p.website ?? "#"} target="_blank" rel="noreferrer" title="Website" style={{ color: "var(--accent)" }}><Globe size={16} /></a>
                    {p.facebook_url && <a href={p.facebook_url} target="_blank" rel="noreferrer" title="Facebook" style={{ color: "#1877f2" }}><Facebook size={16} /></a>}
                    {p.instagram_url && <a href={p.instagram_url} target="_blank" rel="noreferrer" title="Instagram" style={{ color: "#e1306c" }}><Instagram size={16} /></a>}
                    {p.linkedin_url && <a href={p.linkedin_url} target="_blank" rel="noreferrer" title="LinkedIn" style={{ color: "#0a66c2" }}><Linkedin size={16} /></a>}
                    <button
                      className="btn ml-auto p-0 text-xs"
                      style={{ background: "transparent", color: "var(--accent)" }}
                      onClick={() => setOpenMsg(openMsg === p.discoveryId ? null : p.discoveryId)}
                    >
                      <Wand2 size={14} /> Outreach
                    </button>
                  </div>

                  {openMsg === p.discoveryId && (
                    <div className="rounded-[10px] p-3 text-[12.3px] leading-relaxed" style={{ background: "var(--input-bg)" }}>
                      {outreachFor(p)}
                      <button
                        className="btn mt-2 rounded-md px-2.5 py-1.5 text-[11px]"
                        style={{ background: "var(--surface)", color: "var(--sub)", border: "1px solid var(--border)" }}
                        onClick={() => navigator.clipboard?.writeText(outreachFor(p))}
                      >
                        <Copy size={12} /> Copy message
                      </button>
                    </div>
                  )}

                  <button
                    className="btn mt-auto justify-center rounded-[10px] py-2.5 text-sm"
                    disabled={done || dup}
                    onClick={() => saveOne(p)}
                    style={{
                      background: done ? "var(--accent2)22" : dup ? "var(--input-bg)" : "linear-gradient(135deg, var(--accent), var(--accent2))",
                      color: done ? "var(--accent2)" : dup ? "var(--sub)" : "#04121a",
                      border: dup && !done ? "1px solid var(--border)" : "none",
                    }}
                  >
                    {done ? (<><CheckCircle2 size={15} /> Saved to CRM</>) : dup ? (<><AlertTriangle size={14} /> Already in CRM</>) : (<><Plus size={15} /> Save to CRM</>)}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {!results && !loading && (
        <div className="card p-14 text-center">
          <div className="mx-auto mb-4 grid h-[60px] w-[60px] place-items-center rounded-2xl" style={{ background: "var(--accent)18" }}>
            <Radar size={28} color="var(--accent)" />
          </div>
          <div className="text-[15px] font-bold">Start discovering leads</div>
          <p className="mx-auto mt-1.5 max-w-[380px] text-[13px]" style={{ color: "var(--sub)" }}>
            Pick a state and specialty above, then run a search to surface dental practices with extracted
            contact details, social profiles, and auto-assigned lead scores.
          </p>
        </div>
      )}
    </div>
  );
}
