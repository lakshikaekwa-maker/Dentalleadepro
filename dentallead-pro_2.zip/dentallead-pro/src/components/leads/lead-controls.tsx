"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, Edit3, Loader2 } from "lucide-react";
import type { Lead } from "@/types";
import { addActivity, deleteLead } from "@/app/leads/actions";
import { LeadModal } from "./lead-modal";

export function ContactLog({ leadId }: { leadId: string }) {
  const router = useRouter();
  const [text, setText] = useState("");
  const [saving, setSaving] = useState(false);

  async function add() {
    if (!text.trim()) return;
    setSaving(true);
    await addActivity(leadId, text.trim());
    setText("");
    setSaving(false);
    router.refresh();
  }

  return (
    <div className="flex gap-2">
      <input
        className="input"
        placeholder="Log a contact — e.g. Left voicemail, sent proposal…"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && add()}
      />
      <button
        className="btn rounded-[10px] px-3.5"
        style={{ background: "var(--accent)", color: "#04121a" }}
        onClick={add}
        disabled={saving}
      >
        {saving ? <Loader2 size={16} className="spin" /> : <Plus size={16} />}
      </button>
    </div>
  );
}

export function LeadActions({ lead }: { lead: Lead }) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    if (!confirm(`Delete ${lead.practice_name}? This cannot be undone.`)) return;
    setDeleting(true);
    await deleteLead(lead.id);
    router.push("/leads");
  }

  return (
    <>
      <button
        className="btn rounded-[9px] px-3 py-1.5 text-[12.5px]"
        style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
        onClick={() => setEditing(true)}
      >
        <Edit3 size={13} /> Edit
      </button>
      <button
        className="btn rounded-[9px] px-3 py-1.5 text-[12.5px]"
        style={{ background: "#f8717118", color: "#f87171" }}
        onClick={handleDelete}
        disabled={deleting}
      >
        {deleting ? <Loader2 size={13} className="spin" /> : <Trash2 size={13} />}
      </button>
      {editing && (
        <LeadModal
          lead={lead}
          onClose={() => setEditing(false)}
          onSaved={() => {
            setEditing(false);
            router.refresh();
          }}
        />
      )}
    </>
  );
}
