"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { useDraggable } from "@dnd-kit/core";
import { LEAD_STATUSES, STAGE_COLORS, type Lead, type LeadStatus } from "@/types";
import { scoreColor } from "@/lib/utils";
import { updateLeadStatus } from "@/app/leads/actions";

export function KanbanBoard({ leads: initial }: { leads: Lead[] }) {
  const router = useRouter();
  const [leads, setLeads] = useState<Lead[]>(initial);
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
  );

  const grouped: Record<LeadStatus, Lead[]> = LEAD_STATUSES.reduce(
    (acc, s) => ({ ...acc, [s]: leads.filter((l) => l.status === s) }),
    {} as Record<LeadStatus, Lead[]>,
  );

  function onDragStart(e: DragStartEvent) {
    setActiveId(String(e.active.id));
  }

  async function onDragEnd(e: DragEndEvent) {
    setActiveId(null);
    const id = String(e.active.id);
    const over = e.over?.id as LeadStatus | undefined;
    if (!over) return;
    const lead = leads.find((l) => l.id === id);
    if (!lead || lead.status === over) return;

    // optimistic update
    setLeads((ls) => ls.map((l) => (l.id === id ? { ...l, status: over } : l)));
    try {
      await updateLeadStatus(id, over);
    } catch {
      setLeads(initial); // revert on failure
    }
    router.refresh();
  }

  const activeLead = activeId ? leads.find((l) => l.id === activeId) : null;

  return (
    <DndContext sensors={sensors} onDragStart={onDragStart} onDragEnd={onDragEnd}>
      <div className="flex gap-3.5 overflow-x-auto pb-2.5">
        {LEAD_STATUSES.map((stage) => (
          <Column key={stage} stage={stage} leads={grouped[stage]} />
        ))}
      </div>
      <DragOverlay>
        {activeLead ? <Card lead={activeLead} dragging /> : null}
      </DragOverlay>
    </DndContext>
  );
}

function Column({ stage, leads }: { stage: LeadStatus; leads: Lead[] }) {
  const { setNodeRef, isOver } = useDroppable({ id: stage });
  return (
    <div
      ref={setNodeRef}
      className="flex w-[248px] flex-shrink-0 flex-col rounded-[14px]"
      style={{
        background: "var(--surface2)",
        border: isOver ? "2px dashed var(--accent)" : "1px solid var(--border)",
        maxHeight: "calc(100vh - 150px)",
      }}
    >
      <div
        className="flex items-center justify-between px-3.5 py-3"
        style={{ borderBottom: "1px solid var(--border)" }}
      >
        <div className="flex items-center gap-2 text-[13.5px] font-bold">
          <span className="h-[9px] w-[9px] rounded" style={{ background: STAGE_COLORS[stage] }} />
          {stage}
        </div>
        <span className="chip" style={{ background: "var(--input-bg)", color: "var(--sub)" }}>
          {leads.length}
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-2.5 overflow-y-auto p-2.5">
        {leads.map((l) => (
          <DraggableCard key={l.id} lead={l} />
        ))}
        {leads.length === 0 && (
          <div className="py-4 text-center text-xs opacity-60" style={{ color: "var(--sub)" }}>
            Drop leads here
          </div>
        )}
      </div>
    </div>
  );
}

function DraggableCard({ lead }: { lead: Lead }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: lead.id,
  });
  return (
    <div
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      style={{ opacity: isDragging ? 0.4 : 1, cursor: "grab", touchAction: "none" }}
    >
      <Card lead={lead} />
    </div>
  );
}

function Card({ lead, dragging }: { lead: Lead; dragging?: boolean }) {
  return (
    <div
      className="card p-3"
      style={{
        borderLeft: `3px solid ${STAGE_COLORS[lead.status]}`,
        boxShadow: dragging ? "0 12px 30px -10px rgba(0,0,0,.5)" : undefined,
      }}
    >
      <div className="text-[13px] font-bold">{lead.practice_name}</div>
      <div className="mt-0.5 text-[11.5px]" style={{ color: "var(--sub)" }}>
        {lead.contact_name ?? "—"}
      </div>
      <div className="mt-2.5 flex items-center justify-between">
        <span className="text-[11px]" style={{ color: "var(--sub)" }}>
          {[lead.city, lead.state].filter(Boolean).join(", ")}
        </span>
        <span className="chip" style={{ background: `${scoreColor(lead.score)}22`, color: scoreColor(lead.score) }}>
          {lead.score}
        </span>
      </div>
    </div>
  );
}
