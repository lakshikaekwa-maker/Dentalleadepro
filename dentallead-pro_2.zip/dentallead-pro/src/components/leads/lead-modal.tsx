"use client";

import { useState } from "react";
import { X, Check, Loader2 } from "lucide-react";
import {
  LEAD_STATUSES,
  LEAD_SOURCES,
  SPECIALTIES,
  type Lead,
  type LeadInput,
} from "@/types";
import { emptyLead, scoreColor } from "@/lib/utils";
import { createLead, updateLead } from "@/app/leads/actions";

export function LeadModal({
  lead,
  onClose,
  onSaved,
}: {
  lead: Lead | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<LeadInput>(
    lead
      ? {
          practice_name: lead.practice_name,
          contact_name: lead.contact_name ?? "",
          job_title: lead.job_title ?? "",
          website: lead.website ?? "",
          facebook_url: lead.facebook_url ?? "",
          instagram_url: lead.instagram_url ?? "",
          linkedin_url: lead.linkedin_url ?? "",
          email: lead.email ?? "",
          phone: lead.phone ?? "",
          state: lead.state ?? "",
          city: lead.city ?? "",
          num_locations: lead.num_locations,
          num_dentists: lead.num_dentists,
          specialty: lead.specialty,
          source: lead.source,
          score: lead.score,
          status: lead.status,
          notes: lead.notes ?? "",
          last_contact_date: lead.last_contact_date,
          next_followup_date: lead.next_followup_date,
        }
      : emptyLead(),
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const set = <K extends keyof LeadInput>(key: K, value: LeadInput[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  async function handleSave() {
    if (!form.practice_name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      if (lead) await updateLead(lead.id, form);
      else await createLead(form);
      onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to save");
      setSaving(false);
    }
  }

  const Field = ({
    label,
    k,
    type = "text",
    full,
  }: {
    label: string;
    k: keyof LeadInput;
    type?: string;
    full?: boolean;
  }) => (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
        {label}
      </label>
      {type === "textarea" ? (
        <textarea
          className="input resize-y"
          rows={3}
          value={(form[k] as string) ?? ""}
          onChange={(e) => set(k, e.target.value as never)}
        />
      ) : (
        <input
          className="input"
          type={type}
          value={(form[k] as string | number) ?? ""}
          onChange={(e) =>
            set(
              k,
              (type === "number" ? Number(e.target.value) : e.target.value) as never,
            )
          }
        />
      )}
    </div>
  );

  return (
    <div
      className="fixed inset-0 z-[100] grid place-items-center p-4"
      style={{ background: "rgba(2,6,14,.6)", backdropFilter: "blur(4px)" }}
      onClick={onClose}
    >
      <div
        className="card flex max-h-[90vh] w-full max-w-[720px] flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="flex items-center justify-between px-5 py-4"
          style={{ borderBottom: "1px solid var(--border)" }}
        >
          <h2 className="font-display text-[17px] font-extrabold">
            {lead ? "Edit Lead" : "New Lead"}
          </h2>
          <button
            className="btn rounded-[9px] p-2"
            style={{ background: "var(--input-bg)", color: "var(--sub)" }}
            onClick={onClose}
          >
            <X size={17} />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-3.5 overflow-y-auto p-5 sm:grid-cols-2">
          <Field label="Practice Name *" k="practice_name" full />
          <Field label="Contact Name" k="contact_name" />
          <Field label="Job Title" k="job_title" />
          <Field label="Email" k="email" type="email" />
          <Field label="Phone" k="phone" />
          <Field label="City" k="city" />
          <Field label="State" k="state" />
          <Field label="Website" k="website" />
          <Field label="Facebook URL" k="facebook_url" />
          <Field label="Instagram URL" k="instagram_url" />
          <Field label="LinkedIn URL" k="linkedin_url" />
          <Field label="Number of Locations" k="num_locations" type="number" />
          <Field label="Number of Dentists" k="num_dentists" type="number" />

          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
              Specialty
            </label>
            <select
              className="input"
              value={form.specialty ?? ""}
              onChange={(e) => set("specialty", e.target.value as never)}
            >
              {SPECIALTIES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
              Lead Source
            </label>
            <select
              className="input"
              value={form.source}
              onChange={(e) => set("source", e.target.value as never)}
            >
              {LEAD_SOURCES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
              Status
            </label>
            <select
              className="input"
              value={form.status}
              onChange={(e) => set("status", e.target.value as never)}
            >
              {LEAD_STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
              Lead Score:{" "}
              <b style={{ color: scoreColor(form.score) }}>{form.score}</b>
            </label>
            <input
              type="range"
              min={0}
              max={100}
              value={form.score}
              onChange={(e) => set("score", Number(e.target.value))}
              className="w-full"
              style={{ accentColor: scoreColor(form.score) }}
            />
          </div>
          <Field label="Last Contact Date" k="last_contact_date" type="date" />
          <Field label="Next Follow-Up Date" k="next_followup_date" type="date" />
          <Field label="Notes" k="notes" type="textarea" full />
        </div>

        {error && (
          <div className="px-5 pb-2 text-xs" style={{ color: "#f87171" }}>
            {error}
          </div>
        )}

        <div
          className="flex justify-end gap-2.5 px-5 py-3.5"
          style={{ borderTop: "1px solid var(--border)" }}
        >
          <button
            className="btn rounded-[10px] px-4 py-2.5 text-sm"
            style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className="btn rounded-[10px] px-5 py-2.5 text-sm font-bold"
            disabled={!form.practice_name.trim() || saving}
            onClick={handleSave}
            style={{
              background: "linear-gradient(135deg, var(--accent), var(--accent2))",
              color: "#04121a",
            }}
          >
            {saving ? <Loader2 size={16} className="spin" /> : <Check size={16} />}
            Save Lead
          </button>
        </div>
      </div>
    </div>
  );
}
