"use client";

import { useFormStatus } from "react-dom";
import { useActionState } from "react";
import Link from "next/link";
import { Stethoscope, Loader2 } from "lucide-react";
import type { AuthState } from "@/app/login/actions";

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="btn w-full justify-center rounded-[10px] py-3 text-sm font-bold"
      style={{
        background: "linear-gradient(135deg, var(--accent), var(--accent2))",
        color: "#04121a",
      }}
    >
      {pending && <Loader2 size={16} className="spin" />}
      {label}
    </button>
  );
}

export function AuthForm({
  mode,
  action,
}: {
  mode: "login" | "signup";
  action: (prev: AuthState, fd: FormData) => Promise<AuthState>;
}) {
  const [state, formAction] = useActionState<AuthState, FormData>(action, {});
  const isLogin = mode === "login";

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4"
      style={{ background: "var(--bg)" }}
    >
      <div className="card w-full max-w-md p-8" style={{ animation: "fade .4s ease both" }}>
        <div className="mb-6 flex items-center gap-3">
          <div
            className="grid h-11 w-11 place-items-center rounded-xl"
            style={{
              background: "linear-gradient(135deg, var(--accent), var(--accent2))",
            }}
          >
            <Stethoscope size={22} color="#04121a" />
          </div>
          <div>
            <div className="font-display text-lg font-extrabold">DentalLead Pro</div>
            <div className="text-xs font-semibold" style={{ color: "var(--accent)" }}>
              {isLogin ? "Welcome back" : "Create your account"}
            </div>
          </div>
        </div>

        <form action={formAction} className="flex flex-col gap-4">
          <div>
            <label className="mb-1 block text-xs font-semibold" style={{ color: "var(--sub)" }}>
              Email
            </label>
            <input
              name="email"
              type="email"
              required
              autoComplete="email"
              className="input"
              placeholder="you@company.com"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-semibold" style={{ color: "var(--sub)" }}>
              Password
            </label>
            <input
              name="password"
              type="password"
              required
              minLength={6}
              autoComplete={isLogin ? "current-password" : "new-password"}
              className="input"
              placeholder="••••••••"
            />
          </div>

          {state.error && (
            <div
              className="rounded-[10px] px-3 py-2 text-xs font-medium"
              style={{ background: "#f8717122", color: "#f87171" }}
            >
              {state.error}
            </div>
          )}
          {state.message && (
            <div
              className="rounded-[10px] px-3 py-2 text-xs font-medium"
              style={{ background: "#34d39922", color: "var(--accent2)" }}
            >
              {state.message}
            </div>
          )}

          <SubmitButton label={isLogin ? "Sign in" : "Create account"} />
        </form>

        <div className="mt-5 text-center text-xs" style={{ color: "var(--sub)" }}>
          {isLogin ? (
            <>
              No account?{" "}
              <Link href="/signup" className="font-semibold" style={{ color: "var(--accent)" }}>
                Sign up
              </Link>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <Link href="/login" className="font-semibold" style={{ color: "var(--accent)" }}>
                Sign in
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
