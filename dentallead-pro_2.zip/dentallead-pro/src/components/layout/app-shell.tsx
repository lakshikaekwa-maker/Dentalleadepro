"use client";

import { useState, type ReactNode } from "react";
import { Menu, X } from "lucide-react";
import { Sidebar } from "./sidebar";
import { ThemeToggle } from "./theme-toggle";

export function AppShell({
  title,
  actions,
  children,
}: {
  title: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "var(--bg)" }}>
      {/* Desktop sidebar */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0"
            style={{ background: "rgba(2,6,14,.6)" }}
            onClick={() => setOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full">
            <Sidebar onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}

      <main className="flex min-w-0 flex-1 flex-col">
        <header
          className="flex flex-wrap items-center gap-3 px-4 py-3.5 md:px-6"
          style={{ borderBottom: "1px solid var(--border)", background: "var(--surface)" }}
        >
          <button
            className="btn rounded-[10px] p-2 md:hidden"
            style={{ background: "var(--input-bg)", color: "var(--text)" }}
            onClick={() => setOpen((o: boolean) => !o)}
            aria-label="Toggle menu"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
          <h1 className="font-display text-lg font-extrabold tracking-tight">{title}</h1>
          <div className="ml-auto flex items-center gap-2">
            {actions}
            <ThemeToggle />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto px-4 pb-16 pt-5 md:px-6" style={{ animation: "fade .35s ease both" }}>
          {children}
        </div>
      </main>
    </div>
  );
}
