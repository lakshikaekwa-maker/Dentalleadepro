"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const isDark = theme === "dark";
  return (
    <button
      aria-label="Toggle theme"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className="btn rounded-[10px] p-[9px]"
      style={{
        background: "var(--input-bg)",
        color: "var(--text)",
        border: "1px solid var(--border)",
      }}
    >
      {mounted ? isDark ? <Sun size={16} /> : <Moon size={16} /> : <Sun size={16} />}
    </button>
  );
}
