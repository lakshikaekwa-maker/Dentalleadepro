"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  KanbanSquare,
  CalendarClock,
  BarChart3,
  Radar,
  Stethoscope,
  Sparkles,
  LogOut,
} from "lucide-react";
import { signout } from "@/app/login/actions";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/discovery", label: "Lead Discovery", icon: Radar },
  { href: "/leads", label: "Leads", icon: Users },
  { href: "/pipeline", label: "Pipeline", icon: KanbanSquare },
  { href: "/followups", label: "Follow-Ups", icon: CalendarClock },
  { href: "/reports", label: "Reports", icon: BarChart3 },
];

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <aside
      className="flex h-full w-[236px] flex-col gap-1.5 p-4"
      style={{ background: "var(--surface)", borderRight: "1px solid var(--border)" }}
    >
      <div className="flex items-center gap-3 px-2 pb-5 pt-1">
        <div
          className="grid h-[38px] w-[38px] place-items-center rounded-xl"
          style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))" }}
        >
          <Stethoscope size={20} color="#04121a" />
        </div>
        <div>
          <div className="font-display text-base font-extrabold tracking-tight">
            DentalLead
          </div>
          <div
            className="-mt-0.5 text-[10.5px] font-bold tracking-widest"
            style={{ color: "var(--accent)" }}
          >
            PRO · CRM
          </div>
        </div>
      </div>

      {NAV.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(`${href}/`);
        return (
          <Link
            key={href}
            href={href}
            onClick={onNavigate}
            className="row-hover flex items-center gap-3 rounded-[11px] px-3 py-[11px] text-sm font-semibold transition-all"
            style={{
              background: active
                ? "linear-gradient(90deg, var(--accent), transparent)"
                : "transparent",
              color: active ? "var(--text)" : "var(--sub)",
              borderLeft: active
                ? "3px solid var(--accent)"
                : "3px solid transparent",
            }}
          >
            <Icon size={18} color={active ? "var(--accent)" : "var(--sub)"} />
            {label}
          </Link>
        );
      })}

      <div
        className="mt-auto rounded-[13px] border p-3.5"
        style={{
          background: "linear-gradient(135deg, var(--accent)14, var(--accent2)10)",
          borderColor: "var(--border)",
        }}
      >
        <div className="flex items-center gap-2 text-[13px] font-bold">
          <Sparkles size={15} color="var(--accent)" /> AI Assistant
        </div>
        <p className="mt-1.5 text-[11.5px] leading-relaxed" style={{ color: "var(--sub)" }}>
          Open any lead to draft outreach, analyze practices &amp; score leads.
        </p>
      </div>

      <form action={signout}>
        <button
          type="submit"
          className="row-hover mt-1 flex w-full items-center gap-3 rounded-[11px] px-3 py-[11px] text-sm font-semibold"
          style={{ color: "var(--sub)", background: "transparent" }}
        >
          <LogOut size={18} /> Sign out
        </button>
      </form>
    </aside>
  );
}
