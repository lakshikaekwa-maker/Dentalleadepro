"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import { SOURCE_COLORS } from "@/types";

export function StateBarChart({
  data,
}: {
  data: { state: string; count: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}>
        <XAxis type="number" hide />
        <YAxis
          type="category"
          dataKey="state"
          width={42}
          tick={{ fill: "var(--sub)", fontSize: 12, fontWeight: 700 }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip
          cursor={{ fill: "var(--hover)" }}
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: 10,
            color: "var(--text)",
            fontSize: 12,
          }}
        />
        <Bar dataKey="count" radius={[0, 6, 6, 0]} fill="var(--accent)" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function SourcePieChart({
  data,
}: {
  data: { source: string; count: number }[];
}) {
  const filtered = data.filter((d) => d.count > 0);
  return (
    <ResponsiveContainer width="100%" height={260}>
      <PieChart>
        <Pie
          data={filtered}
          dataKey="count"
          nameKey="source"
          innerRadius={55}
          outerRadius={90}
          paddingAngle={2}
        >
          {filtered.map((d) => (
            <Cell
              key={d.source}
              fill={SOURCE_COLORS[d.source as keyof typeof SOURCE_COLORS] ?? "#94a3b8"}
            />
          ))}
        </Pie>
        <Tooltip
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: 10,
            color: "var(--text)",
            fontSize: 12,
          }}
        />
        <Legend
          wrapperStyle={{ fontSize: 12, color: "var(--sub)" }}
          iconType="circle"
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
