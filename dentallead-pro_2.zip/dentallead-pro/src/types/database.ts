// Database schema types for the Supabase client.
// Mirrors supabase/schema.sql. If you change the schema, regenerate with:
//   npx supabase gen types typescript --project-id <ref> > src/types/database.ts

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      leads: {
        Row: {
          id: string;
          user_id: string;
          practice_name: string;
          contact_name: string | null;
          job_title: string | null;
          website: string | null;
          facebook_url: string | null;
          instagram_url: string | null;
          linkedin_url: string | null;
          email: string | null;
          phone: string | null;
          state: string | null;
          city: string | null;
          num_locations: number;
          num_dentists: number;
          specialty: string | null;
          source: string;
          score: number;
          status: string;
          notes: string | null;
          last_contact_date: string | null;
          next_followup_date: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          practice_name: string;
          contact_name?: string | null;
          job_title?: string | null;
          website?: string | null;
          facebook_url?: string | null;
          instagram_url?: string | null;
          linkedin_url?: string | null;
          email?: string | null;
          phone?: string | null;
          state?: string | null;
          city?: string | null;
          num_locations?: number;
          num_dentists?: number;
          specialty?: string | null;
          source?: string;
          score?: number;
          status?: string;
          notes?: string | null;
          last_contact_date?: string | null;
          next_followup_date?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["leads"]["Insert"]>;
        Relationships: [];
      };
      activities: {
        Row: {
          id: string;
          lead_id: string;
          user_id: string;
          message: string;
          kind: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          lead_id: string;
          user_id: string;
          message: string;
          kind?: string;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["activities"]["Insert"]>;
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
}
