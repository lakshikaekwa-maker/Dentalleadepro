export const LEAD_STATUSES = [
  "New",
  "Contacted",
  "Meeting Scheduled",
  "Proposal Sent",
  "Negotiation",
  "Won",
  "Lost",
] as const;

export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const LEAD_SOURCES = [
  "Facebook",
  "Instagram",
  "LinkedIn",
  "Google Search",
  "Referral",
  "Website",
  "Discovery",
  "Other",
] as const;

export type LeadSource = (typeof LEAD_SOURCES)[number];

export const SPECIALTIES = [
  "General Dentistry",
  "Orthodontics",
  "Pediatric Dentistry",
  "Periodontics",
  "Endodontics",
  "Oral Surgery",
  "Prosthodontics",
  "Cosmetic Dentistry",
] as const;

export type Specialty = (typeof SPECIALTIES)[number];

/** A lead row as stored in the database (snake_case mirrors Postgres columns). */
export interface Lead {
  id: string;
  user_id: string;
  practice_name: string;
  contact_name: string | null;
  job_title: string | null;
  website: string | null;
  facebook_url: string | null;
  instagram_url: string | null;
  linkedin_url: string | null;
  email: string | null;
  phone: string | null;
  state: string | null;
  city: string | null;
  num_locations: number;
  num_dentists: number;
  specialty: Specialty | null;
  source: LeadSource;
  score: number;
  status: LeadStatus;
  notes: string | null;
  last_contact_date: string | null; // ISO date
  next_followup_date: string | null; // ISO date
  created_at: string;
  updated_at: string;
}

/** Shape used by insert/update forms (server fills user_id, id, timestamps). */
export type LeadInput = Omit<
  Lead,
  "id" | "user_id" | "created_at" | "updated_at"
>;

export interface Activity {
  id: string;
  lead_id: string;
  user_id: string;
  message: string;
  kind: "system" | "log" | "stage" | "import";
  created_at: string;
}

export const STAGE_COLORS: Record<LeadStatus, string> = {
  New: "#60a5fa",
  Contacted: "#a78bfa",
  "Meeting Scheduled": "#22d3ee",
  "Proposal Sent": "#fbbf24",
  Negotiation: "#fb923c",
  Won: "#34d399",
  Lost: "#f87171",
};

export const SOURCE_COLORS: Record<LeadSource, string> = {
  Facebook: "#1877f2",
  Instagram: "#e1306c",
  LinkedIn: "#0a66c2",
  "Google Search": "#ea4335",
  Referral: "#10b981",
  Website: "#8b5cf6",
  Discovery: "#22d3ee",
  Other: "#94a3b8",
};

export type AiAction =
  | "analyze"
  | "outreach_email"
  | "linkedin_message"
  | "facebook_message"
  | "followup_email"
  | "score_recommendation";
