import { AppShell } from "@/components/layout/app-shell";
import { DiscoveryClient } from "@/components/leads/discovery-client";
import { createClient } from "@/lib/supabase/server";
import { dedupeKey } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function DiscoveryPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("leads").select("email, practice_name");

  const existingKeys = (data ?? []).map((l: { email: string | null; practice_name: string }) =>
    dedupeKey({ email: l.email, practice_name: l.practice_name }),
  );

  return (
    <AppShell title="Lead Discovery">
      <DiscoveryClient existingKeys={existingKeys} />
    </AppShell>
  );
}
