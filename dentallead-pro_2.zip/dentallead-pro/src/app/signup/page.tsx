import { AuthForm } from "@/components/auth-form";
import { signup } from "@/app/login/actions";

export default function SignupPage() {
  return <AuthForm mode="signup" action={signup} />;
}
