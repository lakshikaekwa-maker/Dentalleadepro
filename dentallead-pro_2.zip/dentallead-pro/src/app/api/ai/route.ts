import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { buildPrompt, fallbackGenerate } from "@/lib/ai";
import type { AiAction, Lead } from "@/types";

export const runtime = "nodejs";

interface Body {
  action: AiAction;
  lead: Partial<Lead> & { practice_name: string };
}

export async function POST(request: Request) {
  // Require an authenticated user.
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { action, lead } = body;
  if (!action || !lead?.practice_name) {
    return NextResponse.json(
      { error: "Missing action or lead" },
      { status: 400 },
    );
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;

  // No key configured -> deterministic offline fallback so the app still works.
  if (!apiKey) {
    return NextResponse.json({
      text: fallbackGenerate(action, lead),
      source: "fallback",
    });
  }

  try {
    const prompt = buildPrompt(action, lead);
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 700,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      // Fall back gracefully on upstream errors.
      return NextResponse.json({
        text: fallbackGenerate(action, lead),
        source: "fallback",
      });
    }

    const data = (await res.json()) as {
      content?: Array<{ type: string; text?: string }>;
    };
    const text =
      data.content
        ?.filter((b) => b.type === "text")
        .map((b) => b.text ?? "")
        .join("\n")
        .trim() || fallbackGenerate(action, lead);

    return NextResponse.json({ text, source: "anthropic" });
  } catch {
    return NextResponse.json({
      text: fallbackGenerate(action, lead),
      source: "fallback",
    });
  }
}
