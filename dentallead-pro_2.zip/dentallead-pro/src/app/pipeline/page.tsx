import { AppShell } from "@/components/layout/app-shell";
import { KanbanBoard } from "@/components/leads/kanban-board";
import { createClient } from "@/lib/supabase/server";
import type { Lead } from "@/types";

export const dynamic = "force-dynamic";

export default async function PipelinePage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("leads")
    .select("*")
    .order("score", { ascending: false });

  return (
    <AppShell title="Sales Pipeline">
      <p className="mb-4 text-sm" style={{ color: "var(--sub)" }}>
        Drag a card between stages to update its status. Changes save automatically.
      </p>
      <KanbanBoard leads={(data ?? []) as Lead[]} />
    </AppShell>
  );
}
