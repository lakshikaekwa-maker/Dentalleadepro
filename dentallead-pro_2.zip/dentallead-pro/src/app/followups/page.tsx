import Link from "next/link";
import {
  AlertTriangle,
  Clock,
  CalendarClock,
  ChevronRight,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { createClient } from "@/lib/supabase/server";
import { formatDate, daysUntil } from "@/lib/utils";
import { STAGE_COLORS, type Lead } from "@/types";

export const dynamic = "force-dynamic";

export default async function FollowUpsPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("leads")
    .select("*")
    .not("next_followup_date", "is", null)
    .order("next_followup_date", { ascending: true });

  const leads = (data ?? []) as Lead[];
  const overdue = leads.filter((l) => (daysUntil(l.next_followup_date) ?? 1) < 0);
  const today = leads.filter((l) => daysUntil(l.next_followup_date) === 0);
  const upcoming = leads.filter((l) => (daysUntil(l.next_followup_date) ?? -1) > 0);

  const buckets: Array<[string, Lead[], string, typeof Clock]> = [
    ["Overdue", overdue, "#f87171", AlertTriangle],
    ["Due Today", today, "#fbbf24", Clock],
    ["Upcoming", upcoming, "var(--accent)", CalendarClock],
  ];

  return (
    <AppShell title="Follow-Up Management">
      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {buckets.map(([label, list, color, Icon]) => (
          <div key={label} className="card flex items-center gap-3.5 p-4">
            <div className="grid h-[38px] w-[38px] place-items-center rounded-[11px]" style={{ background: `${color}22` }}>
              <Icon size={19} color={color} />
            </div>
            <div>
              <div className="font-display text-2xl font-extrabold">{list.length}</div>
              <div className="text-xs font-semibold" style={{ color: "var(--sub)" }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col gap-5">
        {buckets.map(([label, list, color]) =>
          list.length > 0 ? (
            <div key={label}>
              <div className="mb-2 flex items-center gap-1.5 text-[13px] font-bold" style={{ color }}>
                <span className="h-2 w-2 rounded" style={{ background: color }} />
                {label} ({list.length})
              </div>
              <div className="card overflow-hidden">
                {list.map((l, i) => {
                  const days = daysUntil(l.next_followup_date);
                  return (
                    <Link
                      key={l.id}
                      href={`/leads/${l.id}`}
                      className="row-hover flex items-center gap-3.5 px-4 py-3"
                      style={{ borderBottom: i < list.length - 1 ? "1px solid var(--border)" : "none" }}
                    >
                      <div className="flex-1">
                        <div className="text-[13.5px] font-bold">{l.practice_name}</div>
                        <div className="text-xs" style={{ color: "var(--sub)" }}>
                          {l.contact_name ?? "—"} · {l.job_title ?? ""}
                        </div>
                      </div>
                      <span className="chip" style={{ background: `${STAGE_COLORS[l.status]}22`, color: STAGE_COLORS[l.status] }}>
                        {l.status}
                      </span>
                      <div className="min-w-[96px] text-right text-[12.5px]" style={{ color }}>
                        {days !== null && days < 0
                          ? `${-days}d overdue`
                          : days === 0
                            ? "Today"
                            : formatDate(l.next_followup_date)}
                      </div>
                      <ChevronRight size={16} style={{ color: "var(--sub)" }} />
                    </Link>
                  );
                })}
              </div>
            </div>
          ) : null,
        )}
        {leads.length === 0 && (
          <div className="card p-10 text-center" style={{ color: "var(--sub)" }}>
            No follow-ups scheduled. Set a “Next Follow-Up Date” on any lead to see it here.
          </div>
        )}
      </div>
    </AppShell>
  );
}
