import { TrendingUp, Globe, MapPin, Activity as ActivityIcon } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { createClient } from "@/lib/supabase/server";
import { scoreColor } from "@/lib/utils";
import {
  LEAD_SOURCES,
  LEAD_STATUSES,
  STAGE_COLORS,
  SOURCE_COLORS,
  type Activity,
  type Lead,
} from "@/types";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const supabase = await createClient();
  const { data: leadData } = await supabase.from("leads").select("*");
  const leads = (leadData ?? []) as Lead[];

  const { data: actData } = await supabase
    .from("activities")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(12);
  const activities = (actData ?? []) as Activity[];

  const total = leads.length;
  const won = leads.filter((l) => l.status === "Won").length;
  const lost = leads.filter((l) => l.status === "Lost").length;
  const winRate = won + lost ? Math.round((won / (won + lost)) * 100) : 0;

  const sourcePerf = LEAD_SOURCES.map((s) => {
    const ls = leads.filter((l) => l.source === s);
    const w = ls.filter((l) => l.status === "Won").length;
    return { source: s, total: ls.length, won: w, rate: ls.length ? Math.round((w / ls.length) * 100) : 0 };
  })
    .filter((r) => r.total > 0)
    .sort((a, b) => b.total - a.total);

  const stateRep = Object.entries(
    leads.reduce<Record<string, { t: number; w: number }>>((m, l) => {
      const k = l.state ?? "—";
      m[k] = m[k] ?? { t: 0, w: 0 };
      m[k].t++;
      if (l.status === "Won") m[k].w++;
      return m;
    }, {}),
  )
    .map(([state, v]) => ({ state, ...v }))
    .sort((a, b) => b.t - a.t);

  const funnel = LEAD_STATUSES.filter((s) => s !== "Lost").map((s) => ({
    stage: s,
    n: leads.filter((l) => l.status === s).length,
  }));
  const maxFunnel = Math.max(1, ...funnel.map((f) => f.n));

  return (
    <AppShell title="Reporting">
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
          {([
            ["Total Acquired", total, "var(--accent)"],
            ["Closed Won", won, "#34d399"],
            ["Closed Lost", lost, "#f87171"],
            ["Win Rate", `${winRate}%`, "var(--accent2)"],
          ] as Array<[string, number | string, string]>).map(([l, v, c]) => (
            <div key={l} className="card p-4">
              <div className="text-[12.5px] font-semibold" style={{ color: "var(--sub)" }}>{l}</div>
              <div className="mt-1.5 font-display text-2xl font-extrabold" style={{ color: c }}>{v}</div>
            </div>
          ))}
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="card p-5">
            <Title icon={<TrendingUp size={16} color="var(--accent)" />}>Sales Conversion Funnel</Title>
            {funnel.map((f) => (
              <div key={f.stage} className="mb-3">
                <div className="mb-1 flex justify-between text-[12.5px]">
                  <span className="font-semibold" style={{ color: "var(--sub)" }}>{f.stage}</span>
                  <b>{f.n}</b>
                </div>
                <div className="h-2.5 overflow-hidden rounded-md" style={{ background: "var(--input-bg)" }}>
                  <div className="h-full rounded-md" style={{ width: `${(f.n / maxFunnel) * 100}%`, background: STAGE_COLORS[f.stage] }} />
                </div>
              </div>
            ))}
          </div>

          <div className="card p-5">
            <Title icon={<Globe size={16} color="var(--accent)" />}>Source Performance Report</Title>
            <table className="w-full border-collapse text-[13px]">
              <thead>
                <tr className="text-[11px] uppercase" style={{ color: "var(--sub)" }}>
                  <th className="pb-2.5 text-left">Source</th>
                  <th className="pb-2.5">Leads</th>
                  <th className="pb-2.5">Won</th>
                  <th className="pb-2.5">Rate</th>
                </tr>
              </thead>
              <tbody>
                {sourcePerf.map((r) => (
                  <tr key={r.source} style={{ borderTop: "1px solid var(--border)" }}>
                    <td className="py-2.5 font-semibold">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded" style={{ background: SOURCE_COLORS[r.source] }} />
                        {r.source}
                      </span>
                    </td>
                    <td className="py-2.5 text-center">{r.total}</td>
                    <td className="py-2.5 text-center font-bold" style={{ color: "#34d399" }}>{r.won}</td>
                    <td className="py-2.5 text-center">
                      <span className="chip" style={{ background: `${scoreColor(r.rate)}22`, color: scoreColor(r.rate) }}>{r.rate}%</span>
                    </td>
                  </tr>
                ))}
                {sourcePerf.length === 0 && (
                  <tr><td colSpan={4} className="py-6 text-center" style={{ color: "var(--sub)" }}>No data yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card p-5">
          <Title icon={<MapPin size={16} color="var(--accent)" />}>State-wise Lead Report</Title>
          {stateRep.length ? (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
              {stateRep.map((r) => (
                <div key={r.state} className="rounded-[10px] border p-3" style={{ background: "var(--surface2)", borderColor: "var(--border)" }}>
                  <div className="font-display text-lg font-extrabold">{r.state}</div>
                  <div className="mt-0.5 text-[11.5px]" style={{ color: "var(--sub)" }}>
                    {r.t} leads · <span className="font-bold" style={{ color: "#34d399" }}>{r.w} won</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm" style={{ color: "var(--sub)" }}>No data yet.</div>
          )}
        </div>

        <div className="card p-5">
          <Title icon={<ActivityIcon size={16} color="var(--accent)" />}>Sales Activity Report</Title>
          {activities.length ? (
            <div className="flex flex-col gap-2.5">
              {activities.map((a) => (
                <div key={a.id} className="flex items-center gap-3 text-[13px]">
                  <span className="h-2 w-2 rounded-full" style={{ background: a.kind === "log" ? "var(--accent2)" : "var(--accent)" }} />
                  <span className="flex-1">{a.message}</span>
                  <span className="text-[11.5px]" style={{ color: "var(--sub)" }}>
                    {new Date(a.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm" style={{ color: "var(--sub)" }}>No recent activity logged.</div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function Title({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <h3 className="mb-3.5 flex items-center gap-2 font-display text-[14.5px] font-bold">
      {icon}
      {children}
    </h3>
  );
}
