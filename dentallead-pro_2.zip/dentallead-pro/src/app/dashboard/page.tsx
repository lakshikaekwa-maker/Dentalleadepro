import {
  Users,
  Sparkles,
  Phone,
  CalendarClock,
  TrendingUp,
  X,
  Activity,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { StateBarChart, SourcePieChart } from "@/components/dashboard/charts";
import { createClient } from "@/lib/supabase/server";
import { LEAD_SOURCES, STAGE_COLORS, type Lead, type LeadStatus } from "@/types";
import { LEAD_STATUSES } from "@/types";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("leads").select("*");
  const leads = (data ?? []) as Lead[];

  const count = (s: LeadStatus) => leads.filter((l) => l.status === s).length;
  const total = leads.length;
  const won = count("Won");
  const lost = count("Lost");
  const followUps = leads.filter((l) => l.next_followup_date).length;
  const convRate = total ? Math.round((won / total) * 100) : 0;

  const kpis: Array<[string, number | string, typeof Users, string]> = [
    ["Total Leads", total, Users, "var(--accent)"],
    ["New Leads", count("New"), Sparkles, "#60a5fa"],
    ["Contacted", count("Contacted"), Phone, "#a78bfa"],
    ["Follow-Ups", followUps, CalendarClock, "#fbbf24"],
    ["Won Deals", won, TrendingUp, "#34d399"],
    ["Lost Deals", lost, X, "#f87171"],
    ["Conversion Rate", `${convRate}%`, Activity, "var(--accent2)"],
  ];

  const stateMap = new Map<string, number>();
  leads.forEach((l) => {
    if (l.state) stateMap.set(l.state, (stateMap.get(l.state) ?? 0) + 1);
  });
  const stateData = [...stateMap.entries()]
    .map(([state, count]) => ({ state, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const sourceData = LEAD_SOURCES.map((source) => ({
    source,
    count: leads.filter((l) => l.source === source).length,
  }));

  return (
    <AppShell title="Dashboard">
      <div className="mb-5 grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
        {kpis.map(([label, value, Icon, color], i) => (
          <div
            key={label}
            className="card relative overflow-hidden p-4"
            style={{ animation: `rise .5s ${i * 0.05}s both` }}
          >
            <div
              className="absolute -right-2.5 -top-2.5 h-14 w-14 rounded-full opacity-[0.08]"
              style={{ background: color }}
            />
            <div className="flex items-start justify-between">
              <div className="text-[12.5px] font-semibold" style={{ color: "var(--sub)" }}>
                {label}
              </div>
              <div
                className="grid h-[30px] w-[30px] place-items-center rounded-[9px]"
                style={{ background: `${color}22` }}
              >
                <Icon size={16} color={color} />
              </div>
            </div>
            <div className="mt-2 font-display text-3xl font-extrabold tracking-tight">
              {value}
            </div>
          </div>
        ))}
      </div>

      <div className="mb-4 grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-2 font-display text-[15px] font-bold">Leads by State</h3>
          {stateData.length ? (
            <StateBarChart data={stateData} />
          ) : (
            <Empty />
          )}
        </div>
        <div className="card p-5">
          <h3 className="mb-2 font-display text-[15px] font-bold">Leads by Source</h3>
          {total ? <SourcePieChart data={sourceData} /> : <Empty />}
        </div>
      </div>

      <div className="card p-5">
        <h3 className="mb-3.5 font-display text-[15px] font-bold">Pipeline Distribution</h3>
        <div className="flex h-10 gap-1.5 overflow-hidden rounded-[10px]">
          {LEAD_STATUSES.map((s) => {
            const n = count(s);
            if (!n) return null;
            return (
              <div
                key={s}
                title={`${s}: ${n}`}
                className="grid min-w-[34px] place-items-center"
                style={{ flex: n, background: STAGE_COLORS[s] }}
              >
                <span className="text-xs font-extrabold" style={{ color: "#04121a" }}>
                  {n}
                </span>
              </div>
            );
          })}
          {total === 0 && <Empty />}
        </div>
        <div className="mt-3.5 flex flex-wrap gap-3.5">
          {LEAD_STATUSES.map((s) => (
            <div key={s} className="flex items-center gap-1.5 text-xs" style={{ color: "var(--sub)" }}>
              <span className="h-2.5 w-2.5 rounded" style={{ background: STAGE_COLORS[s] }} />
              {s} <b style={{ color: "var(--text)" }}>{count(s)}</b>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

function Empty() {
  return (
    <div className="grid h-[200px] place-items-center text-sm" style={{ color: "var(--sub)" }}>
      No data yet — add or import leads to get started.
    </div>
  );
}
