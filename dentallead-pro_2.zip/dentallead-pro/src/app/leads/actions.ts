"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { computeLeadScore, dedupeKey } from "@/lib/utils";
import type { Lead, LeadInput, LeadStatus } from "@/types";

async function requireUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  return { supabase, user };
}

function normalize(input: Partial<LeadInput>): Partial<LeadInput> {
  const out: Partial<LeadInput> = { ...input };
  // Empty strings -> null for optional text columns
  for (const key of Object.keys(out) as (keyof LeadInput)[]) {
    if (out[key] === "") (out as Record<string, unknown>)[key] = null;
  }
  return out;
}

export async function createLead(input: LeadInput) {
  const { supabase, user } = await requireUser();
  const score =
    input.score && input.score > 0 ? input.score : computeLeadScore(input as Lead);

  const { data, error } = await supabase
    .from("leads")
    .insert({ ...normalize(input), score, user_id: user.id })
    .select()
    .single();
  if (error) throw new Error(error.message);

  await supabase.from("activities").insert({
    lead_id: data.id,
    user_id: user.id,
    message: "Lead created",
    kind: "system",
  });

  revalidatePath("/leads");
  revalidatePath("/dashboard");
  return data as Lead;
}

export async function updateLead(id: string, input: Partial<LeadInput>) {
  const { supabase, user } = await requireUser();
  const { data, error } = await supabase
    .from("leads")
    .update(normalize(input))
    .eq("id", id)
    .eq("user_id", user.id)
    .select()
    .single();
  if (error) throw new Error(error.message);

  revalidatePath("/leads");
  revalidatePath(`/leads/${id}`);
  revalidatePath("/dashboard");
  return data as Lead;
}

export async function updateLeadStatus(id: string, status: LeadStatus) {
  const { supabase, user } = await requireUser();
  const today = new Date().toISOString().slice(0, 10);
  const { error } = await supabase
    .from("leads")
    .update({ status, last_contact_date: today })
    .eq("id", id)
    .eq("user_id", user.id);
  if (error) throw new Error(error.message);

  await supabase.from("activities").insert({
    lead_id: id,
    user_id: user.id,
    message: `Moved to ${status}`,
    kind: "stage",
  });

  revalidatePath("/pipeline");
  revalidatePath("/dashboard");
}

export async function deleteLead(id: string) {
  const { supabase, user } = await requireUser();
  const { error } = await supabase
    .from("leads")
    .delete()
    .eq("id", id)
    .eq("user_id", user.id);
  if (error) throw new Error(error.message);

  revalidatePath("/leads");
  revalidatePath("/dashboard");
}

export async function addActivity(leadId: string, message: string) {
  const { supabase, user } = await requireUser();
  const { error } = await supabase.from("activities").insert({
    lead_id: leadId,
    user_id: user.id,
    message,
    kind: "log",
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/leads/${leadId}`);
}

/** Bulk insert (CSV import / discovery import) skipping in-DB duplicates. */
export async function bulkImportLeads(inputs: Partial<LeadInput>[]) {
  const { supabase, user } = await requireUser();

  const { data: existing } = await supabase
    .from("leads")
    .select("email, practice_name")
    .eq("user_id", user.id);

  const seen = new Set(
    (existing ?? []).map((l: { email: string | null; practice_name: string }) =>
      dedupeKey({ email: l.email, practice_name: l.practice_name }),
    ),
  );

  const toInsert = inputs
    .filter((i) => i.practice_name)
    .filter((i) => {
      const k = dedupeKey({
        email: (i.email as string) ?? null,
        practice_name: i.practice_name as string,
      });
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    })
    .map((i) => {
      const merged = { ...i } as LeadInput;
      const score =
        merged.score && merged.score > 0
          ? merged.score
          : computeLeadScore({
              num_locations: merged.num_locations ?? 1,
              num_dentists: merged.num_dentists ?? 1,
              website: merged.website ?? null,
              facebook_url: merged.facebook_url ?? null,
              instagram_url: merged.instagram_url ?? null,
              linkedin_url: merged.linkedin_url ?? null,
              email: merged.email ?? null,
              phone: merged.phone ?? null,
            } as Lead);
      return {
        ...normalize(merged),
        score,
        status: merged.status ?? "New",
        source: merged.source ?? "Other",
        num_locations: merged.num_locations ?? 1,
        num_dentists: merged.num_dentists ?? 1,
        user_id: user.id,
      };
    });

  if (toInsert.length === 0) {
    return { inserted: 0, skipped: inputs.length };
  }

  const { error, count } = await supabase
    .from("leads")
    .insert(toInsert, { count: "exact" });
  if (error) throw new Error(error.message);

  revalidatePath("/leads");
  revalidatePath("/dashboard");
  return { inserted: count ?? toInsert.length, skipped: inputs.length - toInsert.length };
}
