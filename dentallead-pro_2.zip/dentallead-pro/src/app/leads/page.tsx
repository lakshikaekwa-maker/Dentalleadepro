import { AppShell } from "@/components/layout/app-shell";
import { LeadsTable } from "@/components/leads/leads-table";
import { createClient } from "@/lib/supabase/server";
import type { Lead } from "@/types";

export const dynamic = "force-dynamic";

export default async function LeadsPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("leads")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <AppShell title="Lead Management">
      <LeadsTable leads={(data ?? []) as Lead[]} />
    </AppShell>
  );
}
