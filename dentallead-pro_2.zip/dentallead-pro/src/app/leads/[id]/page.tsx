import { notFound } from "next/navigation";
import Link from "next/link";
import {
  ArrowUpRight,
  Mail,
  Phone,
  MapPin,
  Globe,
  Facebook,
  Instagram,
  Linkedin,
  Building2,
  ChevronRight,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { AiStudio } from "@/components/leads/ai-studio";
import { ContactLog, LeadActions } from "@/components/leads/lead-controls";
import { createClient } from "@/lib/supabase/server";
import { scoreColor, formatDate } from "@/lib/utils";
import { STAGE_COLORS, SOURCE_COLORS, type Activity, type Lead } from "@/types";

export const dynamic = "force-dynamic";

export default async function LeadDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: lead } = await supabase.from("leads").select("*").eq("id", id).single();
  if (!lead) notFound();
  const l = lead as Lead;

  const { data: activityData } = await supabase
    .from("activities")
    .select("*")
    .eq("lead_id", id)
    .order("created_at", { ascending: false });
  const activities = (activityData ?? []) as Activity[];

  return (
    <AppShell title="Lead Details">
      <Link href="/leads" className="mb-4 inline-flex items-center gap-1 text-sm" style={{ color: "var(--accent)" }}>
        <ChevronRight size={15} className="rotate-180" /> Back to leads
      </Link>

      <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        {/* Left: details */}
        <div className="flex flex-col gap-4">
          <div className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="font-display text-xl font-extrabold">{l.practice_name}</h2>
                <div className="mt-0.5 text-[13px]" style={{ color: "var(--sub)" }}>
                  {l.contact_name ?? "—"} · {l.job_title ?? ""}
                </div>
              </div>
              <div className="flex gap-2">
                <LeadActions lead={l} />
              </div>
            </div>
            <div className="mt-3.5 flex flex-wrap gap-2">
              <span className="chip" style={{ background: `${STAGE_COLORS[l.status]}22`, color: STAGE_COLORS[l.status] }}>{l.status}</span>
              <span className="chip" style={{ background: `${scoreColor(l.score)}22`, color: scoreColor(l.score) }}>Score {l.score}</span>
              <span className="chip" style={{ background: `${SOURCE_COLORS[l.source]}22`, color: SOURCE_COLORS[l.source] }}>{l.source}</span>
            </div>
          </div>

          <div className="card p-5">
            <SectionTitle>Contact</SectionTitle>
            <Row icon={<Mail size={15} />} value={l.email} />
            <Row icon={<Phone size={15} />} value={l.phone} />
            <Row icon={<MapPin size={15} />} value={[l.city, l.state].filter(Boolean).join(", ")} />
            <Row icon={<Globe size={15} />} value={l.website} link />
            <div className="mt-3 flex flex-wrap gap-4">
              {l.facebook_url && <Social url={l.facebook_url} icon={<Facebook size={15} />} label="Facebook" color="#1877f2" />}
              {l.instagram_url && <Social url={l.instagram_url} icon={<Instagram size={15} />} label="Instagram" color="#e1306c" />}
              {l.linkedin_url && <Social url={l.linkedin_url} icon={<Linkedin size={15} />} label="LinkedIn" color="#0a66c2" />}
            </div>
          </div>

          <div className="card p-5">
            <SectionTitle>Practice Details</SectionTitle>
            <div className="grid grid-cols-2 gap-2.5">
              <Stat label="Specialty" value={l.specialty ?? "—"} />
              <Stat label="Locations" value={l.num_locations} />
              <Stat label="Dentists" value={l.num_dentists} />
              <Stat label="Last Contact" value={formatDate(l.last_contact_date)} />
              <Stat label="Next Follow-Up" value={formatDate(l.next_followup_date)} />
            </div>
          </div>

          <div className="card p-5">
            <SectionTitle>Notes</SectionTitle>
            <div className="rounded-[10px] p-3 text-[13px] leading-relaxed" style={{ background: "var(--input-bg)" }}>
              {l.notes || "No notes recorded."}
            </div>
          </div>
        </div>

        {/* Right: AI + timeline */}
        <div className="flex flex-col gap-4">
          <div className="card p-5">
            <AiStudio lead={l} />
          </div>

          <div className="card p-5">
            <SectionTitle>Activity</SectionTitle>
            <ContactLog leadId={l.id} />
            <div className="relative mt-4 pl-5">
              <div className="absolute bottom-1 left-[5px] top-1 w-0.5" style={{ background: "var(--border)" }} />
              {activities.length === 0 && (
                <div className="text-[12.5px]" style={{ color: "var(--sub)" }}>
                  No activity yet. Log a contact or move this lead in the pipeline.
                </div>
              )}
              {activities.map((a) => (
                <div key={a.id} className="relative mb-4">
                  <span
                    className="absolute -left-[19px] top-1 h-2.5 w-2.5 rounded-full"
                    style={{
                      background: a.kind === "log" ? "var(--accent2)" : "var(--accent)",
                      border: "2px solid var(--card)",
                    }}
                  />
                  <div className="text-[13px] font-semibold">{a.message}</div>
                  <div className="mt-0.5 text-[11.5px]" style={{ color: "var(--sub)" }}>
                    {formatDate(a.created_at)}
                    {a.kind === "log" && " · Contact log"}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-2.5 text-[11.5px] font-bold uppercase tracking-wide" style={{ color: "var(--sub)" }}>
      {children}
    </div>
  );
}

function Row({ icon, value, link }: { icon: React.ReactNode; value: string | null; link?: boolean }) {
  return (
    <div className="mb-2 flex items-center gap-2.5 text-[13px]">
      <span style={{ color: "var(--sub)" }}>{icon}</span>
      {link && value ? (
        <a href={value} target="_blank" rel="noreferrer" style={{ color: "var(--accent)" }}>
          {value}
        </a>
      ) : (
        <span>{value || "—"}</span>
      )}
    </div>
  );
}

function Social({ url, icon, label, color }: { url: string; icon: React.ReactNode; label: string; color: string }) {
  return (
    <a href={url} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-[12.5px] font-semibold" style={{ color }}>
      {icon}
      {label}
      <ArrowUpRight size={12} />
    </a>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-[10px] p-2.5" style={{ background: "var(--input-bg)" }}>
      <div className="text-[11px] font-semibold" style={{ color: "var(--sub)" }}>{label}</div>
      <div className="mt-0.5 text-[13.5px] font-bold">{value}</div>
    </div>
  );
}
