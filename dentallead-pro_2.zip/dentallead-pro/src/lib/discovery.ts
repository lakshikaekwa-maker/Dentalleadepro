import { computeLeadScore } from "@/lib/utils";
import { SPECIALTIES, type LeadInput, type Specialty } from "@/types";

export const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA",
  "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT",
  "VA","WA","WV","WI","WY",
];

const STATE_CITIES: Record<string, string[]> = {
  CA: ["Los Angeles", "San Diego", "San Jose", "San Francisco", "Sacramento", "Fresno"],
  TX: ["Houston", "Dallas", "Austin", "San Antonio", "Fort Worth"],
  FL: ["Miami", "Orlando", "Tampa", "Jacksonville"],
  NY: ["New York", "Buffalo", "Rochester", "Albany"],
  IL: ["Chicago", "Aurora", "Naperville"],
  WA: ["Seattle", "Spokane", "Tacoma"],
  GA: ["Atlanta", "Savannah", "Augusta"],
  CO: ["Denver", "Boulder", "Colorado Springs"],
  AZ: ["Phoenix", "Tucson", "Mesa"],
  MA: ["Boston", "Cambridge", "Worcester"],
};

const PRE = ["Bright", "Pearl", "Summit", "Lakeside", "Riverstone", "Parkview", "Cedar", "Maplewood", "Sunrise", "Coastal", "Valley", "Premier", "Gentle", "Family", "Modern", "Smile", "Aspen", "Willow", "Harbor", "Oakridge", "Pinecrest", "Meadow", "Crystal", "Radiant", "Evergreen", "Capital", "Metro", "Grandview", "Heritage", "Cornerstone"];

const SUF: Record<Specialty, string[]> = {
  "General Dentistry": ["Dental", "Dental Care", "Family Dentistry", "Dental Group"],
  Orthodontics: ["Orthodontics", "Braces & Aligners", "Orthodontic Studio"],
  "Pediatric Dentistry": ["Pediatric Dentistry", "Kids Dental", "Children's Dental"],
  Periodontics: ["Periodontics", "Gum & Implant Center", "Periodontal Associates"],
  Endodontics: ["Endodontics", "Root Canal Specialists", "Endodontic Group"],
  "Oral Surgery": ["Oral Surgery", "Oral & Maxillofacial Surgery", "Surgical Arts"],
  Prosthodontics: ["Prosthodontics", "Implant & Restorative", "Prosthodontic Center"],
  "Cosmetic Dentistry": ["Cosmetic Dentistry", "Smile Design Studio", "Aesthetic Dental"],
};

const FN = ["James", "Mary", "Robert", "Patricia", "Michael", "Jennifer", "David", "Linda", "Priya", "Wei", "Carlos", "Aisha", "Raj", "Maria", "Susan", "Daniel"];
const LN = ["Smith", "Johnson", "Garcia", "Martinez", "Lee", "Patel", "Nguyen", "Kim", "Chen", "Brown", "Davis", "Lopez", "Wilson", "Cohen", "Murphy", "Shah"];

/** Deterministic PRNG so the same query gives stable results within a session. */
function makeRng(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return () => {
    h ^= h << 13;
    h ^= h >>> 17;
    h ^= h << 5;
    return ((h >>> 0) % 100000) / 100000;
  };
}

export interface DiscoveredLead extends LeadInput {
  discoveryId: string;
}

export interface DiscoveryParams {
  state: string;
  specialty: string;
  minLocations: number;
}

/**
 * PRODUCTION NOTE: replace this with a server call to a real data source
 * (Google Places API + business directory + social profile lookups). The rest
 * of the UI — scoring, dedupe, save — works unchanged.
 */
export function discoverPractices({
  state,
  specialty,
  minLocations,
}: DiscoveryParams): DiscoveredLead[] {
  const rng = makeRng(`${state}|${specialty}|${minLocations}`);
  const cities = STATE_CITIES[state] ?? ["Downtown", "Midtown", "Westside", "Eastgate"];
  const specs: Specialty[] =
    specialty === "All Specialties" ? [...SPECIALTIES] : [specialty as Specialty];
  const count = 8 + Math.floor(rng() * 7);
  const used = new Set<string>();
  const out: DiscoveredLead[] = [];

  for (let i = 0; i < count; i++) {
    const spec = specs[Math.floor(rng() * specs.length)];
    let name = "";
    do {
      name = `${PRE[Math.floor(rng() * PRE.length)]} ${SUF[spec][Math.floor(rng() * SUF[spec].length)]}`;
    } while (used.has(name));
    used.add(name);

    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, "");
    const city = cities[Math.floor(rng() * cities.length)];
    const locations = Math.max(1, minLocations, [1, 1, 1, 2, 2, 3, 4, 6][Math.floor(rng() * 8)]);
    const dentists = locations + Math.floor(rng() * locations * 3) + 1;
    const fn = FN[Math.floor(rng() * FN.length)];
    const ln = LN[Math.floor(rng() * LN.length)];

    const lead: DiscoveredLead = {
      discoveryId: `${slug}${i}`,
      practice_name: name,
      contact_name: `Dr. ${fn} ${ln}`,
      job_title: "Owner / Dentist",
      website: `https://www.${slug}.com`,
      facebook_url: rng() > 0.25 ? `https://facebook.com/${slug}` : "",
      instagram_url: rng() > 0.3 ? `https://instagram.com/${slug}` : "",
      linkedin_url: rng() > 0.45 ? `https://linkedin.com/company/${slug}` : "",
      email: rng() > 0.2 ? `info@${slug}.com` : "",
      phone:
        rng() > 0.1
          ? `(${200 + Math.floor(rng() * 700)}) ${200 + Math.floor(rng() * 700)}-${1000 + Math.floor(rng() * 8999)}`
          : "",
      state,
      city,
      num_locations: locations,
      num_dentists: dentists,
      specialty: spec,
      source: "Discovery",
      score: 50,
      status: "New",
      notes: "",
      last_contact_date: null,
      next_followup_date: null,
    };
    lead.score = computeLeadScore({
      num_locations: lead.num_locations,
      num_dentists: lead.num_dentists,
      website: lead.website,
      facebook_url: lead.facebook_url,
      instagram_url: lead.instagram_url,
      linkedin_url: lead.linkedin_url,
      email: lead.email,
      phone: lead.phone,
    });
    out.push(lead);
  }

  return out.sort((a, b) => b.score - a.score);
}

export function outreachFor(p: DiscoveredLead): string {
  const fn = (p.contact_name ?? "there").replace(/^Dr\.\s*/, "").split(" ")[0];
  const multi = p.num_locations > 1;
  return `Hi ${fn}, I came across ${p.practice_name} while researching top ${(p.specialty ?? "dental").toLowerCase()} practices in ${p.city}, ${p.state}. ${multi ? `Scaling patient acquisition across ${p.num_locations} locations` : "Growing new-patient volume"} is exactly what we help dental practices with. Open to a quick 15-minute call this week?`;
}
