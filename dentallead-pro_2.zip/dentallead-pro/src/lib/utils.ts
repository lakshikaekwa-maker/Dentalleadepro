import type { Lead, LeadInput } from "@/types";

/** Tailwind-friendly hex for a 0-100 score. */
export function scoreColor(score: number): string {
  if (score >= 80) return "#34d399";
  if (score >= 60) return "#fbbf24";
  if (score >= 40) return "#fb923c";
  return "#f87171";
}

/**
 * Deterministic lead-scoring model. Rewards footprint, practice size,
 * digital presence, and contact completeness. Returns 20-99.
 */
export function computeLeadScore(
  lead: Pick<
    Lead,
    | "num_locations"
    | "num_dentists"
    | "website"
    | "facebook_url"
    | "instagram_url"
    | "linkedin_url"
    | "email"
    | "phone"
  >,
): number {
  let s = 30;
  s += Math.min(lead.num_locations ?? 1, 5) * 7;
  s += Math.min(lead.num_dentists ?? 1, 12);
  if (lead.website) s += 8;
  if (lead.facebook_url) s += 5;
  if (lead.instagram_url) s += 5;
  if (lead.linkedin_url) s += 7;
  if (lead.email) s += 6;
  if (lead.phone) s += 4;
  return Math.max(20, Math.min(99, Math.round(s)));
}

export function formatDate(d: string | null | undefined): string {
  if (!d) return "—";
  const date = new Date(d.includes("T") ? d : `${d}T00:00:00`);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function daysUntil(d: string | null | undefined): number | null {
  if (!d) return null;
  const target = new Date(d.includes("T") ? d : `${d}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / 86_400_000);
}

export function isOverdue(d: string | null | undefined): boolean {
  const days = daysUntil(d);
  return days !== null && days < 0;
}

/** Duplicate key: email if present, else normalized practice name. */
export function dedupeKey(
  lead: Pick<Lead, "email" | "practice_name">,
): string {
  return (
    (lead.email ?? "").toLowerCase() ||
    lead.practice_name.toLowerCase().replace(/[^a-z0-9]/g, "")
  );
}

export function findDuplicateIds(leads: Lead[]): Set<string> {
  const byKey = new Map<string, string[]>();
  for (const l of leads) {
    const k = dedupeKey(l);
    if (!k) continue;
    byKey.set(k, [...(byKey.get(k) ?? []), l.id]);
  }
  const dupes = new Set<string>();
  for (const ids of byKey.values()) {
    if (ids.length > 1) ids.forEach((id) => dupes.add(id));
  }
  return dupes;
}

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

/** Empty lead input with sensible defaults for new-lead forms. */
export function emptyLead(): LeadInput {
  return {
    practice_name: "",
    contact_name: "",
    job_title: "",
    website: "",
    facebook_url: "",
    instagram_url: "",
    linkedin_url: "",
    email: "",
    phone: "",
    state: "",
    city: "",
    num_locations: 1,
    num_dentists: 1,
    specialty: "General Dentistry",
    source: "Website",
    score: 50,
    status: "New",
    notes: "",
    last_contact_date: null,
    next_followup_date: null,
  };
}
