import type { AiAction, Lead } from "@/types";

export const AI_ACTION_LABELS: Record<AiAction, string> = {
  analyze: "Analyze Practice",
  outreach_email: "Generate Outreach Email",
  linkedin_message: "Generate LinkedIn Message",
  facebook_message: "Generate Facebook Message",
  followup_email: "Generate Follow-Up Email",
  score_recommendation: "Lead Scoring Recommendation",
};

type LeadCtx = Partial<Lead> & { practice_name: string };

function firstName(lead: LeadCtx): string {
  return (lead.contact_name ?? "there").replace(/^Dr\.\s*/, "").split(" ")[0];
}

/** Builds the user prompt sent to the model for a given action. */
export function buildPrompt(action: AiAction, lead: LeadCtx): string {
  const facts = [
    `Practice: ${lead.practice_name}`,
    lead.contact_name && `Contact: ${lead.contact_name} (${lead.job_title ?? "unknown role"})`,
    lead.specialty && `Specialty: ${lead.specialty}`,
    (lead.city || lead.state) && `Location: ${[lead.city, lead.state].filter(Boolean).join(", ")}`,
    lead.num_locations && `Locations: ${lead.num_locations}`,
    lead.num_dentists && `Dentists: ${lead.num_dentists}`,
    lead.source && `Lead source: ${lead.source}`,
    lead.notes && `Notes: ${lead.notes}`,
  ]
    .filter(Boolean)
    .join("\n");

  const persona =
    "You are an expert B2B sales rep selling patient-acquisition marketing services to U.S. dental practices. Be concise, specific, and never use spammy hype.";

  switch (action) {
    case "analyze":
      return `${persona}\n\nGiven this dental practice, write a short scouting analysis (4-6 bullet points) covering fit, likely pain points, and the best angle for outreach.\n\n${facts}`;
    case "outreach_email":
      return `${persona}\n\nWrite a cold outreach email (subject + body, under 130 words) to this practice. Personalize to their specialty and footprint. End with a soft 15-minute call ask.\n\n${facts}`;
    case "linkedin_message":
      return `${persona}\n\nWrite a LinkedIn connection note under 300 characters, warm and specific.\n\n${facts}`;
    case "facebook_message":
      return `${persona}\n\nWrite a friendly Facebook page DM (2-3 sentences) opening a conversation.\n\n${facts}`;
    case "followup_email":
      return `${persona}\n\nWrite a brief, polite follow-up email (subject + body, under 90 words) for a prospect who hasn't replied yet.\n\n${facts}`;
    case "score_recommendation":
      return `${persona}\n\nRecommend a lead score from 0-100 for this practice and justify it in 2-3 sentences, noting what would raise the score.\n\n${facts}`;
  }
}

/**
 * Deterministic fallback used when ANTHROPIC_API_KEY is not configured, so the
 * product is fully demoable offline. Mirrors the structure the model returns.
 */
export function fallbackGenerate(action: AiAction, lead: LeadCtx): string {
  const fn = firstName(lead);
  const p = lead.practice_name;
  const multi = (lead.num_locations ?? 1) > 1;
  const spec = (lead.specialty ?? "general dentistry").toLowerCase();
  const place = [lead.city, lead.state].filter(Boolean).join(", ") || "your area";

  switch (action) {
    case "analyze":
      return `PRACTICE ANALYSIS — ${p}\n\n• Footprint: ${lead.num_locations ?? 1} location(s), ${lead.num_dentists ?? 1} dentist(s) in ${place}.\n• Specialty: ${lead.specialty ?? "General Dentistry"}.\n• Digital presence: ${[lead.website && "website", lead.facebook_url && "Facebook", lead.instagram_url && "Instagram", lead.linkedin_url && "LinkedIn"].filter(Boolean).join(", ") || "limited"}.\n• Best angle: ${multi ? "centralized multi-location patient acquisition; lead with cost-per-new-patient." : "filling the schedule with higher-value patients; lead with ROI."}\n• Risk: verify decision-maker before investing time.`;
    case "outreach_email":
      return `Subject: Helping ${p} attract more high-value patients\n\nHi ${fn},\n\nI came across ${p} while researching standout ${spec} practices in ${place}. ${multi ? `Scaling acquisition across ${lead.num_locations} locations` : "Growing new-patient volume"} is exactly what we help dental teams with.\n\nWould you be open to a quick 15-minute call this week to see if it's a fit?\n\nBest,\n[Your Name]`;
    case "linkedin_message":
      return `Hi ${fn} — impressed by what ${p} is building in ${place}. I work specifically with ${spec} practices on patient acquisition and thought there might be overlap. Open to connecting?`;
    case "facebook_message":
      return `Hi ${fn}! 👋 Love what ${p} is doing — your page caught my eye. I help dental practices in ${lead.state ?? "your state"} bring in more of the patients they actually want. Mind if I share a quick idea tailored to your practice?`;
    case "followup_email":
      return `Subject: Following up — ${p}\n\nHi ${fn},\n\nJust circling back on my note. If growing new-patient volume is on your radar this quarter, I'd love to show you how we'd approach it for ${p}. Worth a quick chat?\n\nBest,\n[Your Name]`;
    case "score_recommendation": {
      const reasons: string[] = [];
      if (multi) reasons.push("multi-location footprint signals budget");
      if (lead.linkedin_url) reasons.push("LinkedIn presence eases decision-maker outreach");
      if (!lead.email) reasons.push("missing email lowers reachability");
      return `Recommended score: ${lead.score ?? 50}/100.\n\n${reasons.join("; ") || "Limited signal available"}. To raise the score, confirm a direct email/phone for the owner and verify location count.`;
    }
  }
}
