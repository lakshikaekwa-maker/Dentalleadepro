import type { Lead, LeadInput } from "@/types";

const EXPORT_COLUMNS: Array<{ key: keyof Lead; label: string }> = [
  { key: "practice_name", label: "Practice Name" },
  { key: "contact_name", label: "Contact Name" },
  { key: "job_title", label: "Job Title" },
  { key: "email", label: "Email" },
  { key: "phone", label: "Phone" },
  { key: "website", label: "Website" },
  { key: "facebook_url", label: "Facebook" },
  { key: "instagram_url", label: "Instagram" },
  { key: "linkedin_url", label: "LinkedIn" },
  { key: "city", label: "City" },
  { key: "state", label: "State" },
  { key: "num_locations", label: "Locations" },
  { key: "num_dentists", label: "Dentists" },
  { key: "specialty", label: "Specialty" },
  { key: "source", label: "Source" },
  { key: "score", label: "Score" },
  { key: "status", label: "Status" },
  { key: "last_contact_date", label: "Last Contact" },
  { key: "next_followup_date", label: "Next Follow-Up" },
  { key: "notes", label: "Notes" },
];

function escapeCsv(value: unknown): string {
  const v = value === null || value === undefined ? "" : String(value);
  return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}

export function leadsToCsv(leads: Lead[]): string {
  const header = EXPORT_COLUMNS.map((c) => c.label).join(",");
  const rows = leads.map((l) =>
    EXPORT_COLUMNS.map((c) => escapeCsv(l[c.key])).join(","),
  );
  return [header, ...rows].join("\n");
}

export function downloadBlob(content: BlobPart, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportCsv(leads: Lead[]) {
  downloadBlob(leadsToCsv(leads), "dentallead-export.csv", "text/csv");
}

/** Excel export via SheetJS (dynamic import keeps it out of the main bundle). */
export async function exportExcel(leads: Lead[]) {
  const XLSX = await import("xlsx");
  const data = leads.map((l) => {
    const row: Record<string, unknown> = {};
    for (const c of EXPORT_COLUMNS) row[c.label] = l[c.key] ?? "";
    return row;
  });
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Leads");
  XLSX.writeFile(wb, "dentallead-export.xlsx");
}

/** Maps common CSV header variants to our LeadInput keys. */
const HEADER_MAP: Record<string, keyof LeadInput> = {
  "practice name": "practice_name",
  practice: "practice_name",
  "contact name": "contact_name",
  contact: "contact_name",
  "job title": "job_title",
  title: "job_title",
  email: "email",
  phone: "phone",
  website: "website",
  facebook: "facebook_url",
  "facebook url": "facebook_url",
  instagram: "instagram_url",
  "instagram url": "instagram_url",
  linkedin: "linkedin_url",
  "linkedin url": "linkedin_url",
  city: "city",
  state: "state",
  locations: "num_locations",
  "number of locations": "num_locations",
  dentists: "num_dentists",
  "number of dentists": "num_dentists",
  specialty: "specialty",
  source: "source",
  "lead source": "source",
  score: "score",
  "lead score": "score",
  status: "status",
  notes: "notes",
  "last contact": "last_contact_date",
  "next follow-up": "next_followup_date",
};

/** Minimal RFC-4180-ish CSV parser (handles quotes, commas, newlines). */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += ch;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

export function csvToLeads(text: string): Partial<LeadInput>[] {
  const rows = parseCsv(text);
  if (rows.length < 2) return [];
  const headers = rows[0].map((h) => h.trim().toLowerCase());
  const numeric: Array<keyof LeadInput> = [
    "num_locations",
    "num_dentists",
    "score",
  ];

  return rows.slice(1).map((cells) => {
    const lead: Partial<LeadInput> = {};
    headers.forEach((h, idx) => {
      const key = HEADER_MAP[h];
      if (!key) return;
      const raw = (cells[idx] ?? "").trim();
      if (numeric.includes(key)) {
        (lead as Record<string, unknown>)[key] = Number(raw) || 0;
      } else {
        (lead as Record<string, unknown>)[key] = raw;
      }
    });
    return lead;
  });
}
