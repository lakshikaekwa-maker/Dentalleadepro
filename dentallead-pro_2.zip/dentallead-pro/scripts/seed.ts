/**
 * Seeds the database with sample leads for a given user.
 *
 * Usage:
 *   1. Sign up a user in the app (or via Supabase dashboard) and copy their UUID.
 *   2. Ensure .env.local has NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.
 *   3. Run:  SEED_USER_ID=<uuid> npm run seed
 */
import { createClient } from "@supabase/supabase-js";
import { SAMPLE_LEADS } from "../src/lib/sample-data";
import type { Database } from "../src/types/database";

async function main() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const userId = process.env.SEED_USER_ID;

  if (!url || !serviceKey) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in env.",
    );
  }
  if (!userId) {
    throw new Error("Set SEED_USER_ID=<auth user uuid> before running.");
  }

  const supabase = createClient<Database>(url, serviceKey, {
    auth: { persistSession: false },
  });

  const rows = SAMPLE_LEADS.map((l) => ({ ...l, user_id: userId }));
  const { error, count } = await supabase
    .from("leads")
    .insert(rows, { count: "exact" });

  if (error) throw error;
  console.log(`Seeded ${count ?? rows.length} leads for user ${userId}.`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
