# DentalLead Pro

A production-ready CRM for finding, managing, qualifying, and tracking U.S. dental-practice
sales leads from Facebook, Instagram, LinkedIn, websites, referrals, and other public sources.

**Stack:** Next.js 15 (App Router) · React 18 · TypeScript · Tailwind CSS · Supabase
(Postgres + Auth) · Netlify (hosting + Functions).

---

## Features

- **Dashboard** — Total / New / Contacted / Follow-Up / Won / Lost counts, monthly conversion
  rate, Leads by State, Leads by Source, pipeline distribution.
- **Lead Management** — full lead records, search, multi-field filters, duplicate detection,
  inline edit, CSV import, CSV export, Excel export.
- **Lead Discovery** — search public listings by state + specialty, auto-score, multi-location
  flagging, suggested outreach, one-click save to CRM (dedupes against existing leads).
- **Pipeline** — drag-and-drop Kanban across 7 stages (New → … → Won / Lost).
- **Follow-Ups** — overdue / due-today / upcoming reminders and a daily task list.
- **AI features** — Analyze Practice, Outreach Email, LinkedIn / Facebook messages, Follow-Up
  Email, Lead-Scoring recommendation. Uses the Anthropic API when `ANTHROPIC_API_KEY` is set;
  otherwise falls back to a deterministic local generator so the app is always demoable.
- **Reporting** — source performance, conversion funnel, state-wise report, sales activity.
- **UI** — modern SaaS design, dark mode (default), fully mobile-responsive.
- **Auth & security** — email/password auth via Supabase, route protection in middleware, and
  Row Level Security so every user only ever sees their own data.

---

## Project structure

```
dentallead-pro/
├── netlify/
│   └── functions/
│       └── lead-score.ts          # standalone Netlify Function (server-side scoring)
├── public/                        # static assets
├── scripts/
│   └── seed.ts                    # seed 50 sample leads for a user
├── src/
│   ├── app/
│   │   ├── api/ai/route.ts        # AI route handler (Anthropic + fallback)
│   │   ├── dashboard/page.tsx
│   │   ├── discovery/page.tsx
│   │   ├── followups/page.tsx
│   │   ├── leads/
│   │   │   ├── [id]/page.tsx       # lead detail (AI studio, timeline, contact log)
│   │   │   ├── actions.ts          # lead CRUD + bulk import server actions
│   │   │   └── page.tsx
│   │   ├── login/                  # login page + auth server actions
│   │   ├── pipeline/page.tsx
│   │   ├── reports/page.tsx
│   │   ├── signup/page.tsx
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx                # redirects based on auth
│   ├── components/                 # UI components (layout, leads, dashboard)
│   ├── lib/
│   │   ├── supabase/               # browser / server / middleware clients
│   │   ├── ai.ts                   # prompt builders + offline fallback
│   │   ├── csv.ts                  # CSV import/export, Excel export
│   │   ├── discovery.ts            # discovery generator (swap for a real API)
│   │   ├── sample-data.ts          # 50 sample leads
│   │   └── utils.ts                # scoring, dates, dedupe
│   ├── types/                      # domain + database types
│   └── middleware.ts               # session refresh + route guards
├── supabase/
│   └── schema.sql                  # tables, indexes, triggers, RLS policies
├── .env.example
├── netlify.toml
├── next.config.mjs
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

---

## 1. Prerequisites

- Node.js **18.18+** (Node 20 recommended)
- A free [Supabase](https://supabase.com) project
- (Optional) an [Anthropic API key](https://console.anthropic.com) for live AI
- (For deploy) a [Netlify](https://netlify.com) account

---

## 2. Set up Supabase

1. Create a new project in the Supabase dashboard.
2. Open **SQL Editor → New query**, paste the contents of [`supabase/schema.sql`](supabase/schema.sql),
   and click **Run**. This creates the `leads` and `activities` tables, indexes, the
   `updated_at` trigger, and Row Level Security policies.
3. Go to **Project Settings → API** and copy:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public** key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role** key → `SUPABASE_SERVICE_ROLE_KEY` (server only — keep secret)
4. (Optional, smoother demo) Under **Authentication → Providers → Email**, turn **off**
   "Confirm email" so new signups can log in immediately.

---

## 3. Run locally

```bash
# 1. Install dependencies
npm install

# 2. Create your local env file and fill in the values from step 2
cp .env.example .env.local

# 3. Start the dev server
npm run dev
```

Open <http://localhost:3000>. You'll be redirected to **/login** — create an account on
**/signup**, then you're in.

### Seed sample data (optional)

After creating a user, copy its UUID from **Supabase → Authentication → Users**, then:

```bash
SEED_USER_ID=<that-uuid> npm run seed
```

This inserts 50 realistic sample dental practices for that user. (You can also just use the
**Lead Discovery** page in the app to generate and save leads.)

---

## 4. Deploy to Netlify

The repo is preconfigured for Netlify — no code changes required.

### Option A — Git (recommended)

1. Push this project to GitHub/GitLab/Bitbucket.
2. In Netlify: **Add new site → Import an existing project**, pick the repo.
3. Build settings are read from `netlify.toml` automatically
   (build `npm run build`, the official `@netlify/plugin-nextjs` runtime handles the rest).
4. Add environment variables under **Site settings → Environment variables**:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `ANTHROPIC_API_KEY` (optional)
   - `NEXT_PUBLIC_SITE_URL` → your Netlify site URL (e.g. `https://your-site.netlify.app`)
5. **Deploy site.**
6. In **Supabase → Authentication → URL Configuration**, add your Netlify URL to
   **Site URL** and **Redirect URLs** so auth redirects resolve.

### Option B — Netlify CLI

```bash
npm install -g netlify-cli
netlify login
netlify init        # link or create a site
netlify env:import .env.local   # or set vars individually with `netlify env:set`
netlify deploy --build --prod
```

---

## Available scripts

| Command            | Description                                  |
| ------------------ | -------------------------------------------- |
| `npm run dev`      | Start the local dev server                   |
| `npm run build`    | Production build                             |
| `npm run start`    | Run the production build locally             |
| `npm run lint`     | Lint with ESLint / next                      |
| `npm run typecheck`| Type-check with `tsc --noEmit`               |
| `npm run seed`     | Seed 50 sample leads (needs `SEED_USER_ID`)  |

---

## Notes & production hardening

- **Lead Discovery** ships with a local generator (`src/lib/discovery.ts`) that simulates what a
  real data source would return, so the workflow is fully demoable offline. To go live, replace
  the `discoverPractices()` body with a server call to a real provider (e.g. Google Places API
  plus social-profile lookups). Everything downstream — scoring, dedupe, outreach, save — is
  unchanged. Always confirm contact details and respect opt-out / anti-spam rules (CAN-SPAM,
  platform ToS) before any outreach.
- **AI** runs server-side only; your `ANTHROPIC_API_KEY` is never exposed to the browser. With no
  key set, the deterministic fallback keeps every AI button working.
- **Security:** RLS is enforced at the database, and middleware guards every private route, so a
  user can only read/write their own leads even if client code is tampered with.
