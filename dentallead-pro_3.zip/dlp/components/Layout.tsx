import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import {
  LayoutDashboard,
  Users,
  KanbanSquare,
  CalendarClock,
  BarChart3,
  Radar,
  Stethoscope,
  Menu,
  X,
  Moon,
  Sun,
} from "lucide-react";

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/discovery", label: "Lead Discovery", icon: Radar },
  { href: "/leads", label: "Leads", icon: Users },
  { href: "/pipeline", label: "Pipeline", icon: KanbanSquare },
  { href: "/followups", label: "Follow-Ups", icon: CalendarClock },
  { href: "/reports", label: "Reports", icon: BarChart3 },
];

export default function Layout({
  title,
  actions,
  children,
}: {
  title: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);

  const Side = (
    <aside
      className="flex h-full w-[236px] flex-col gap-1.5 p-4"
      style={{ background: "var(--surface)", borderRight: "1px solid var(--border)" }}
    >
      <div className="flex items-center gap-3 px-2 pb-5 pt-1">
        <div
          className="grid h-[38px] w-[38px] place-items-center rounded-xl"
          style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))" }}
        >
          <Stethoscope size={20} color="#04121a" />
        </div>
        <div>
          <div className="text-base font-extrabold tracking-tight">DentalLead</div>
          <div className="-mt-0.5 text-[10.5px] font-bold tracking-widest" style={{ color: "var(--accent)" }}>
            PRO · CRM
          </div>
        </div>
      </div>
      {NAV.map(({ href, label, icon: Icon }) => {
        const active = router.pathname === href;
        return (
          <Link
            key={href}
            href={href}
            onClick={() => setOpen(false)}
            className="flex items-center gap-3 rounded-[11px] px-3 py-[11px] text-sm font-semibold transition-all"
            style={{
              background: active ? "linear-gradient(90deg,var(--accent),transparent)" : "transparent",
              color: active ? "var(--text)" : "var(--sub)",
              borderLeft: active ? "3px solid var(--accent)" : "3px solid transparent",
            }}
          >
            <Icon size={18} color={active ? "var(--accent)" : "var(--sub)"} />
            {label}
          </Link>
        );
      })}
    </aside>
  );

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "var(--bg)", color: "var(--text)" }}>
      <div className="hidden md:block">{Side}</div>

      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0" style={{ background: "rgba(2,6,14,.6)" }} onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 h-full">{Side}</div>
        </div>
      )}

      <main className="flex min-w-0 flex-1 flex-col">
        <header
          className="flex flex-wrap items-center gap-3 px-4 py-3.5 md:px-6"
          style={{ borderBottom: "1px solid var(--border)", background: "var(--surface)" }}
        >
          <button
            className="btn rounded-[10px] p-2 md:hidden"
            style={{ background: "var(--input-bg)", color: "var(--text)" }}
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
          <h1 className="text-lg font-extrabold tracking-tight">{title}</h1>
          <div className="ml-auto flex items-center gap-2">
            {actions}
            <button
              className="btn rounded-[10px] p-[9px]"
              style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
              onClick={() => setDark((d) => !d)}
              aria-label="Theme"
            >
              {dark ? <Sun size={16} /> : <Moon size={16} />}
            </button>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto px-4 pb-16 pt-5 md:px-6">{children}</div>
      </main>
    </div>
  );
}
