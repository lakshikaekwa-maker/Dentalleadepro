import { useState } from "react";
import { X, Check } from "lucide-react";
import {
  LEAD_STATUSES,
  LEAD_SOURCES,
  SPECIALTIES,
  type Lead,
  type LeadInput,
} from "@/lib/types";
import { scoreColor } from "@/lib/utils";

function emptyLead(): LeadInput {
  return {
    practice_name: "",
    contact_name: "",
    job_title: "",
    website: "",
    facebook_url: "",
    instagram_url: "",
    linkedin_url: "",
    email: "",
    phone: "",
    state: "",
    city: "",
    num_locations: 1,
    num_dentists: 1,
    specialty: "General Dentistry",
    source: "Website",
    score: 50,
    status: "New",
    notes: "",
    last_contact_date: null,
    next_followup_date: null,
  };
}

export default function LeadModal({
  lead,
  onClose,
  onSave,
}: {
  lead: Lead | null;
  onClose: () => void;
  onSave: (data: LeadInput, id?: string) => void;
}) {
  const [form, setForm] = useState<LeadInput>(
    lead ? { ...lead } : emptyLead(),
  );

  const set = <K extends keyof LeadInput>(k: K, v: LeadInput[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  function field(label: string, k: keyof LeadInput, type = "text", full = false) {
    return (
      <div className={full ? "sm:col-span-2" : ""}>
        <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
          {label}
        </label>
        {type === "textarea" ? (
          <textarea
            className="input resize-y"
            rows={3}
            value={(form[k] as string) ?? ""}
            onChange={(e) => set(k, e.target.value as never)}
          />
        ) : (
          <input
            className="input"
            type={type}
            value={(form[k] as string | number) ?? ""}
            onChange={(e) =>
              set(k, (type === "number" ? Number(e.target.value) : e.target.value) as never)
            }
          />
        )}
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-[100] grid place-items-center p-4"
      style={{ background: "rgba(2,6,14,.6)" }}
      onClick={onClose}
    >
      <div
        className="card flex max-h-[90vh] w-full max-w-[720px] flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
          <h2 className="text-[17px] font-extrabold">{lead ? "Edit Lead" : "New Lead"}</h2>
          <button className="btn rounded-[9px] p-2" style={{ background: "var(--input-bg)", color: "var(--sub)" }} onClick={onClose}>
            <X size={17} />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-3.5 overflow-y-auto p-5 sm:grid-cols-2">
          {field("Practice Name *", "practice_name", "text", true)}
          {field("Contact Name", "contact_name")}
          {field("Job Title", "job_title")}
          {field("Email", "email", "email")}
          {field("Phone", "phone")}
          {field("City", "city")}
          {field("State", "state")}
          {field("Website", "website")}
          {field("Facebook URL", "facebook_url")}
          {field("Instagram URL", "instagram_url")}
          {field("LinkedIn URL", "linkedin_url")}
          {field("Number of Locations", "num_locations", "number")}
          {field("Number of Dentists", "num_dentists", "number")}

          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Specialty</label>
            <select className="input" value={form.specialty ?? ""} onChange={(e) => set("specialty", e.target.value as never)}>
              {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Lead Source</label>
            <select className="input" value={form.source} onChange={(e) => set("source", e.target.value as never)}>
              {LEAD_SOURCES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Status</label>
            <select className="input" value={form.status} onChange={(e) => set("status", e.target.value as never)}>
              {LEAD_STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>
              Lead Score: <b style={{ color: scoreColor(form.score) }}>{form.score}</b>
            </label>
            <input
              type="range"
              min={0}
              max={100}
              value={form.score}
              onChange={(e) => set("score", Number(e.target.value))}
              className="w-full"
              style={{ accentColor: scoreColor(form.score) }}
            />
          </div>
          {field("Last Contact Date", "last_contact_date", "date")}
          {field("Next Follow-Up Date", "next_followup_date", "date")}
          {field("Notes", "notes", "textarea", true)}
        </div>

        <div className="flex justify-end gap-2.5 px-5 py-3.5" style={{ borderTop: "1px solid var(--border)" }}>
          <button
            className="btn rounded-[10px] px-4 py-2.5 text-sm"
            style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className="btn rounded-[10px] px-5 py-2.5 text-sm font-bold"
            disabled={!form.practice_name.trim()}
            onClick={() => onSave(form, lead?.id)}
            style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))", color: "#04121a" }}
          >
            <Check size={16} /> Save Lead
          </button>
        </div>
      </div>
    </div>
  );
}
