/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: { 400: "#22d3ee", 500: "#06b6d4", 600: "#0891b2" },
        accent2: { 400: "#34d399", 500: "#10b981", 600: "#059669" },
      },
    },
  },
  plugins: [],
};
