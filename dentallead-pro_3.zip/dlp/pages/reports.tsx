import { useMemo } from "react";
import { TrendingUp, Globe, MapPin } from "lucide-react";
import Layout from "@/components/Layout";
import { useLeads } from "@/lib/useLeads";
import { scoreColor } from "@/lib/utils";
import { LEAD_SOURCES, LEAD_STATUSES, STAGE_COLORS, SOURCE_COLORS } from "@/lib/types";

export default function ReportsPage() {
  const { leads, loading } = useLeads();

  const data = useMemo(() => {
    const total = leads.length;
    const won = leads.filter((l) => l.status === "Won").length;
    const lost = leads.filter((l) => l.status === "Lost").length;
    const winRate = won + lost ? Math.round((won / (won + lost)) * 100) : 0;

    const sourcePerf = LEAD_SOURCES.map((s) => {
      const ls = leads.filter((l) => l.source === s);
      const w = ls.filter((l) => l.status === "Won").length;
      return { source: s, total: ls.length, won: w, rate: ls.length ? Math.round((w / ls.length) * 100) : 0 };
    }).filter((r) => r.total > 0).sort((a, b) => b.total - a.total);

    const stateRep = Object.entries(
      leads.reduce<Record<string, { t: number; w: number }>>((m, l) => {
        const k = l.state ?? "—";
        m[k] = m[k] ?? { t: 0, w: 0 };
        m[k].t++;
        if (l.status === "Won") m[k].w++;
        return m;
      }, {}),
    ).map(([state, v]) => ({ state, ...v })).sort((a, b) => b.t - a.t);

    const funnel = LEAD_STATUSES.filter((s) => s !== "Lost").map((s) => ({ stage: s, n: leads.filter((l) => l.status === s).length }));
    return { total, won, lost, winRate, sourcePerf, stateRep, funnel, maxFunnel: Math.max(1, ...funnel.map((f) => f.n)) };
  }, [leads]);

  return (
    <Layout title="Reporting">
      {loading ? (
        <div className="grid h-64 place-items-center text-sm" style={{ color: "var(--sub)" }}>Loading…</div>
      ) : (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
            {([
              ["Total Acquired", data.total, "var(--accent)"],
              ["Closed Won", data.won, "#34d399"],
              ["Closed Lost", data.lost, "#f87171"],
              ["Win Rate", `${data.winRate}%`, "var(--accent2)"],
            ] as Array<[string, number | string, string]>).map(([l, v, c]) => (
              <div key={l} className="card p-4">
                <div className="text-[12.5px] font-semibold" style={{ color: "var(--sub)" }}>{l}</div>
                <div className="mt-1.5 text-2xl font-extrabold" style={{ color: c }}>{v}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="card p-5">
              <h3 className="mb-3.5 flex items-center gap-2 text-[14.5px] font-bold"><TrendingUp size={16} color="var(--accent)" /> Conversion Funnel</h3>
              {data.funnel.map((f) => (
                <div key={f.stage} className="mb-3">
                  <div className="mb-1 flex justify-between text-[12.5px]"><span className="font-semibold" style={{ color: "var(--sub)" }}>{f.stage}</span><b>{f.n}</b></div>
                  <div className="h-2.5 overflow-hidden rounded-md" style={{ background: "var(--input-bg)" }}>
                    <div className="h-full rounded-md" style={{ width: `${(f.n / data.maxFunnel) * 100}%`, background: STAGE_COLORS[f.stage] }} />
                  </div>
                </div>
              ))}
            </div>

            <div className="card p-5">
              <h3 className="mb-3.5 flex items-center gap-2 text-[14.5px] font-bold"><Globe size={16} color="var(--accent)" /> Source Performance</h3>
              <table className="w-full border-collapse text-[13px]">
                <thead>
                  <tr className="text-[11px] uppercase" style={{ color: "var(--sub)" }}>
                    <th className="pb-2.5 text-left">Source</th><th className="pb-2.5">Leads</th><th className="pb-2.5">Won</th><th className="pb-2.5">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {data.sourcePerf.map((r) => (
                    <tr key={r.source} style={{ borderTop: "1px solid var(--border)" }}>
                      <td className="py-2.5 font-semibold"><span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded" style={{ background: SOURCE_COLORS[r.source] }} />{r.source}</span></td>
                      <td className="py-2.5 text-center">{r.total}</td>
                      <td className="py-2.5 text-center font-bold" style={{ color: "#34d399" }}>{r.won}</td>
                      <td className="py-2.5 text-center"><span className="chip" style={{ background: `${scoreColor(r.rate)}22`, color: scoreColor(r.rate) }}>{r.rate}%</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-3.5 flex items-center gap-2 text-[14.5px] font-bold"><MapPin size={16} color="var(--accent)" /> State-wise Lead Report</h3>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
              {data.stateRep.map((r) => (
                <div key={r.state} className="rounded-[10px] border p-3" style={{ background: "var(--surface2)", borderColor: "var(--border)" }}>
                  <div className="text-lg font-extrabold">{r.state}</div>
                  <div className="mt-0.5 text-[11.5px]" style={{ color: "var(--sub)" }}>{r.t} leads · <span className="font-bold" style={{ color: "#34d399" }}>{r.w} won</span></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
