import { useMemo, useState } from "react";
import {
  Radar,
  Search,
  Info,
  Layers,
  Globe,
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  Phone,
  Building2,
  Plus,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import Layout from "@/components/Layout";
import { useLeads } from "@/lib/useLeads";
import { scoreColor, computeScore, dedupeKey } from "@/lib/utils";
import { SPECIALTIES, type LeadInput, type Specialty } from "@/lib/types";

const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];
const STATE_CITIES: Record<string, string[]> = {
  CA: ["Los Angeles", "San Diego", "San Jose", "Fresno"],
  TX: ["Houston", "Dallas", "Austin", "Fort Worth"],
  FL: ["Miami", "Orlando", "Tampa"],
  NY: ["New York", "Buffalo", "Albany"],
  WA: ["Seattle", "Spokane"],
};
const PRE = ["Bright", "Pearl", "Summit", "Lakeside", "Parkview", "Cedar", "Sunrise", "Coastal", "Valley", "Premier", "Gentle", "Modern", "Aspen", "Harbor", "Meadow", "Crystal", "Evergreen", "Metro", "Heritage", "Cornerstone"];
const SUF: Record<Specialty, string[]> = {
  "General Dentistry": ["Dental", "Family Dentistry", "Dental Group"],
  Orthodontics: ["Orthodontics", "Braces & Aligners"],
  "Pediatric Dentistry": ["Pediatric Dentistry", "Kids Dental"],
  Periodontics: ["Periodontics", "Gum & Implant Center"],
  Endodontics: ["Endodontics", "Root Canal Specialists"],
  "Oral Surgery": ["Oral Surgery", "Surgical Arts"],
  Prosthodontics: ["Prosthodontics", "Implant & Restorative"],
  "Cosmetic Dentistry": ["Cosmetic Dentistry", "Smile Design Studio"],
};
const FN = ["James", "Mary", "David", "Linda", "Priya", "Wei", "Carlos", "Aisha", "Raj", "Maria"];
const LN = ["Smith", "Garcia", "Lee", "Patel", "Nguyen", "Kim", "Chen", "Cohen", "Murphy", "Shah"];

function makeRng(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 100000) / 100000; };
}

interface Discovered extends LeadInput { discoveryId: string }

function discover(state: string, specialty: string, minLoc: number): Discovered[] {
  const rng = makeRng(`${state}|${specialty}|${minLoc}`);
  const cities = STATE_CITIES[state] ?? ["Downtown", "Midtown", "Westside", "Eastgate"];
  const specs: Specialty[] = specialty === "All Specialties" ? [...SPECIALTIES] : [specialty as Specialty];
  const count = 8 + Math.floor(rng() * 7);
  const used = new Set<string>();
  const out: Discovered[] = [];
  for (let i = 0; i < count; i++) {
    const spec = specs[Math.floor(rng() * specs.length)];
    let name = "";
    do { name = `${PRE[Math.floor(rng() * PRE.length)]} ${SUF[spec][Math.floor(rng() * SUF[spec].length)]}`; } while (used.has(name));
    used.add(name);
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, "");
    const city = cities[Math.floor(rng() * cities.length)];
    const locations = Math.max(1, minLoc, [1, 1, 2, 2, 3, 4][Math.floor(rng() * 6)]);
    const dentists = locations + Math.floor(rng() * locations * 3) + 1;
    const fn = FN[Math.floor(rng() * FN.length)];
    const ln = LN[Math.floor(rng() * LN.length)];
    const p: Discovered = {
      discoveryId: `${slug}${i}`,
      practice_name: name,
      contact_name: `Dr. ${fn} ${ln}`,
      job_title: "Owner / Dentist",
      website: `https://www.${slug}.com`,
      facebook_url: rng() > 0.25 ? `https://facebook.com/${slug}` : null,
      instagram_url: rng() > 0.3 ? `https://instagram.com/${slug}` : null,
      linkedin_url: rng() > 0.45 ? `https://linkedin.com/company/${slug}` : null,
      email: rng() > 0.2 ? `info@${slug}.com` : null,
      phone: rng() > 0.1 ? `(${200 + Math.floor(rng() * 700)}) ${200 + Math.floor(rng() * 700)}-${1000 + Math.floor(rng() * 8999)}` : null,
      state,
      city,
      num_locations: locations,
      num_dentists: dentists,
      specialty: spec,
      source: "Discovery",
      score: 50,
      status: "New",
      notes: null,
      last_contact_date: null,
      next_followup_date: null,
    };
    p.score = computeScore(p);
    out.push(p);
  }
  return out.sort((a, b) => b.score - a.score);
}

export default function DiscoveryPage() {
  const { leads, createLead } = useLeads();
  const [state, setState] = useState("CA");
  const [specialty, setSpecialty] = useState("All Specialties");
  const [minLoc, setMinLoc] = useState(1);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Discovered[] | null>(null);
  const [saved, setSaved] = useState<Record<string, boolean>>({});

  const knownKeys = useMemo(() => new Set(leads.map((l) => dedupeKey(l))), [leads]);
  const isKnown = (p: Discovered) => knownKeys.has(dedupeKey(p));

  function run() {
    setLoading(true);
    setResults(null);
    setSaved({});
    setTimeout(() => {
      setResults(discover(state, specialty, minLoc));
      setLoading(false);
    }, 700);
  }

  function save(p: Discovered) {
    const { discoveryId, ...input } = p;
    createLead(input);
    setSaved((s) => ({ ...s, [discoveryId]: true }));
  }

  const multiCount = results ? results.filter((p) => p.num_locations > 1).length : 0;

  return (
    <Layout title="Lead Discovery">
      <div className="card mb-4 p-5">
        <div className="mb-1 flex items-center gap-2.5">
          <div className="grid h-[34px] w-[34px] place-items-center rounded-[10px]" style={{ background: "var(--accent)22" }}>
            <Radar size={18} color="var(--accent)" />
          </div>
          <div>
            <h2 className="text-[17px] font-extrabold">Discover New Leads</h2>
            <div className="text-[12.5px]" style={{ color: "var(--sub)" }}>Find dental practices by state and specialty.</div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>U.S. State</label>
            <select className="input" value={state} onChange={(e) => setState(e.target.value)}>{US_STATES.map((s) => <option key={s}>{s}</option>)}</select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Specialty</label>
            <select className="input" value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
              <option>All Specialties</option>
              {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Min Locations</label>
            <input className="input" type="number" min={1} value={minLoc} onChange={(e) => setMinLoc(Number(e.target.value) || 1)} />
          </div>
          <div className="flex items-end">
            <button className="btn w-full justify-center rounded-[10px] py-2.5 text-sm font-bold" style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))", color: "#04121a", height: 42 }} onClick={run} disabled={loading}>
              <Search size={16} /> {loading ? "Searching…" : "Discover"}
            </button>
          </div>
        </div>
      </div>

      <div className="mb-4 flex items-start gap-2.5 rounded-[11px] border px-3.5 py-2.5 text-xs leading-relaxed" style={{ background: "var(--input-bg)", borderColor: "var(--border)", color: "var(--sub)" }}>
        <Info size={15} color="var(--accent)" className="mt-0.5 flex-shrink-0" />
        <span>Results are generated locally to illustrate the workflow. Connect a real directory/social API in production, and always respect opt-out / anti-spam rules before outreach.</span>
      </div>

      {results && !loading && (
        <>
          <div className="mb-3.5 flex flex-wrap items-center gap-3 text-sm font-bold">
            {results.length} practices found
            <span className="chip flex items-center gap-1" style={{ background: "var(--accent2)22", color: "var(--accent2)" }}><Layers size={12} /> {multiCount} multi-location</span>
          </div>
          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 xl:grid-cols-3">
            {results.map((p) => {
              const done = saved[p.discoveryId];
              const dup = !done && isKnown(p);
              return (
                <div key={p.discoveryId} className="card flex flex-col gap-2.5 p-4" style={{ borderTop: `3px solid ${scoreColor(p.score)}` }}>
                  <div className="flex justify-between gap-2.5">
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[14.5px] font-extrabold">
                        {p.practice_name}
                        {p.num_locations > 1 && <span className="chip inline-flex items-center gap-1" style={{ background: "var(--accent2)22", color: "var(--accent2)" }}><Layers size={10} /> {p.num_locations}</span>}
                      </div>
                      <div className="mt-0.5 text-xs" style={{ color: "var(--sub)" }}>{p.specialty} · {p.city}, {p.state}</div>
                    </div>
                    <div className="flex-shrink-0 text-center">
                      <div className="grid h-[42px] w-[42px] place-items-center rounded-[11px]" style={{ background: `${scoreColor(p.score)}22` }}>
                        <span className="text-base font-extrabold" style={{ color: scoreColor(p.score) }}>{p.score}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 text-[12.5px]" style={{ color: "var(--sub)" }}>
                    <span className="flex items-center gap-1.5"><Building2 size={13} />{p.contact_name} · {p.num_dentists} dentists</span>
                    {p.email && <span className="flex items-center gap-1.5"><Mail size={13} />{p.email}</span>}
                    {p.phone && <span className="flex items-center gap-1.5"><Phone size={13} />{p.phone}</span>}
                  </div>
                  <div className="flex items-center gap-3.5 pt-0.5">
                    {p.website && <a href={p.website} target="_blank" rel="noreferrer" style={{ color: "var(--accent)" }}><Globe size={16} /></a>}
                    {p.facebook_url && <a href={p.facebook_url} target="_blank" rel="noreferrer" style={{ color: "#1877f2" }}><Facebook size={16} /></a>}
                    {p.instagram_url && <a href={p.instagram_url} target="_blank" rel="noreferrer" style={{ color: "#e1306c" }}><Instagram size={16} /></a>}
                    {p.linkedin_url && <a href={p.linkedin_url} target="_blank" rel="noreferrer" style={{ color: "#0a66c2" }}><Linkedin size={16} /></a>}
                  </div>
                  <button
                    className="btn mt-auto justify-center rounded-[10px] py-2.5 text-sm"
                    disabled={done || dup}
                    onClick={() => save(p)}
                    style={{
                      background: done ? "var(--accent2)22" : dup ? "var(--input-bg)" : "linear-gradient(135deg,var(--accent),var(--accent2))",
                      color: done ? "var(--accent2)" : dup ? "var(--sub)" : "#04121a",
                      border: dup ? "1px solid var(--border)" : "none",
                    }}
                  >
                    {done ? (<><CheckCircle2 size={15} /> Saved</>) : dup ? (<><AlertTriangle size={14} /> Already in CRM</>) : (<><Plus size={15} /> Save to CRM</>)}
                  </button>
                </div>
              );
            })}
          </div>
        </>
      )}

      {!results && !loading && (
        <div className="card p-14 text-center">
          <div className="mx-auto mb-4 grid h-[60px] w-[60px] place-items-center rounded-2xl" style={{ background: "var(--accent)18" }}>
            <Radar size={28} color="var(--accent)" />
          </div>
          <div className="text-[15px] font-bold">Start discovering leads</div>
          <p className="mx-auto mt-1.5 max-w-[380px] text-[13px]" style={{ color: "var(--sub)" }}>Pick a state and specialty, then run a search to surface dental practices with auto-assigned scores.</p>
        </div>
      )}
    </Layout>
  );
}
