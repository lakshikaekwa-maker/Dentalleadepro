import { useMemo } from "react";
import {
  Users,
  Sparkles,
  Phone,
  CalendarClock,
  TrendingUp,
  X,
  Activity,
  MapPin,
  Globe,
} from "lucide-react";
import Layout from "@/components/Layout";
import { useLeads } from "@/lib/useLeads";
import {
  LEAD_SOURCES,
  LEAD_STATUSES,
  STAGE_COLORS,
  SOURCE_COLORS,
  type LeadStatus,
} from "@/lib/types";

export default function DashboardPage() {
  const { leads, loading } = useLeads();

  const stats = useMemo(() => {
    const count = (s: LeadStatus) => leads.filter((l) => l.status === s).length;
    const total = leads.length;
    const won = count("Won");
    const stateMap = new Map<string, number>();
    leads.forEach((l) => {
      if (l.state) stateMap.set(l.state, (stateMap.get(l.state) ?? 0) + 1);
    });
    const stateData = [...stateMap.entries()].map(([s, n]) => ({ s, n })).sort((a, b) => b.n - a.n).slice(0, 8);
    const sourceData = LEAD_SOURCES.map((s) => ({ s, n: leads.filter((l) => l.source === s).length })).filter((x) => x.n);
    return {
      total,
      won,
      newL: count("New"),
      contacted: count("Contacted"),
      followUps: leads.filter((l) => l.next_followup_date).length,
      lost: count("Lost"),
      convRate: total ? Math.round((won / total) * 100) : 0,
      stateData,
      sourceData,
      count,
    };
  }, [leads]);

  const maxState = Math.max(1, ...stats.stateData.map((d) => d.n));
  const maxSrc = Math.max(1, ...stats.sourceData.map((d) => d.n));

  const kpis: Array<[string, number | string, typeof Users, string]> = [
    ["Total Leads", stats.total, Users, "var(--accent)"],
    ["New Leads", stats.newL, Sparkles, "#60a5fa"],
    ["Contacted", stats.contacted, Phone, "#a78bfa"],
    ["Follow-Ups", stats.followUps, CalendarClock, "#fbbf24"],
    ["Won Deals", stats.won, TrendingUp, "#34d399"],
    ["Lost Deals", stats.lost, X, "#f87171"],
    ["Conversion Rate", `${stats.convRate}%`, Activity, "var(--accent2)"],
  ];

  return (
    <Layout title="Dashboard">
      {loading ? (
        <Loading />
      ) : (
        <>
          <div className="mb-5 grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
            {kpis.map(([label, value, Icon, color]) => (
              <div key={label} className="card relative overflow-hidden p-4">
                <div className="absolute -right-2.5 -top-2.5 h-14 w-14 rounded-full opacity-[0.08]" style={{ background: color }} />
                <div className="flex items-start justify-between">
                  <div className="text-[12.5px] font-semibold" style={{ color: "var(--sub)" }}>{label}</div>
                  <div className="grid h-[30px] w-[30px] place-items-center rounded-[9px]" style={{ background: `${color}22` }}>
                    <Icon size={16} color={color} />
                  </div>
                </div>
                <div className="mt-2 text-3xl font-extrabold tracking-tight">{value}</div>
              </div>
            ))}
          </div>

          <div className="mb-4 grid gap-4 lg:grid-cols-2">
            <div className="card p-5">
              <h3 className="mb-4 flex items-center gap-2 text-[15px] font-bold">
                <MapPin size={16} color="var(--accent)" /> Leads by State
              </h3>
              {stats.stateData.map(({ s, n }) => (
                <div key={s} className="mb-2.5 flex items-center gap-3">
                  <div className="w-8 text-[13px] font-bold">{s}</div>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-md" style={{ background: "var(--input-bg)" }}>
                    <div className="h-full rounded-md" style={{ width: `${(n / maxState) * 100}%`, background: "linear-gradient(90deg,var(--accent),var(--accent2))" }} />
                  </div>
                  <div className="w-6 text-right text-[13px] font-bold" style={{ color: "var(--sub)" }}>{n}</div>
                </div>
              ))}
            </div>

            <div className="card p-5">
              <h3 className="mb-4 flex items-center gap-2 text-[15px] font-bold">
                <Globe size={16} color="var(--accent)" /> Leads by Source
              </h3>
              {stats.sourceData.map(({ s, n }) => (
                <div key={s} className="mb-2.5 flex items-center gap-3">
                  <div className="w-24 text-[12.5px] font-semibold" style={{ color: "var(--sub)" }}>{s}</div>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-md" style={{ background: "var(--input-bg)" }}>
                    <div className="h-full rounded-md" style={{ width: `${(n / maxSrc) * 100}%`, background: SOURCE_COLORS[s] }} />
                  </div>
                  <div className="w-6 text-right text-[13px] font-bold">{n}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-3.5 text-[15px] font-bold">Pipeline Distribution</h3>
            <div className="flex h-10 gap-1.5 overflow-hidden rounded-[10px]">
              {LEAD_STATUSES.map((s) => {
                const n = stats.count(s);
                if (!n) return null;
                return (
                  <div key={s} title={`${s}: ${n}`} className="grid min-w-[34px] place-items-center" style={{ flex: n, background: STAGE_COLORS[s] }}>
                    <span className="text-xs font-extrabold" style={{ color: "#04121a" }}>{n}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-3.5 flex flex-wrap gap-3.5">
              {LEAD_STATUSES.map((s) => (
                <div key={s} className="flex items-center gap-1.5 text-xs" style={{ color: "var(--sub)" }}>
                  <span className="h-2.5 w-2.5 rounded" style={{ background: STAGE_COLORS[s] }} />
                  {s} <b style={{ color: "var(--text)" }}>{stats.count(s)}</b>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </Layout>
  );
}

function Loading() {
  return (
    <div className="grid h-64 place-items-center text-sm" style={{ color: "var(--sub)" }}>
      Loading…
    </div>
  );
}
