import { useMemo, useState } from "react";
import { useRouter } from "next/router";
import { Search, Plus, Download, Filter, Edit3, Trash2 } from "lucide-react";
import Layout from "@/components/Layout";
import LeadModal from "@/components/LeadModal";
import { useLeads } from "@/lib/useLeads";
import { scoreColor, formatDate, daysUntil, downloadCsv } from "@/lib/utils";
import {
  LEAD_STATUSES,
  LEAD_SOURCES,
  SPECIALTIES,
  STAGE_COLORS,
  SOURCE_COLORS,
  type Lead,
} from "@/lib/types";

export default function LeadsPage() {
  const router = useRouter();
  const { leads, loading, createLead, updateLead, deleteLead } = useLeads();
  const [query, setQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [editing, setEditing] = useState<Lead | "new" | null>(null);
  const [filters, setFilters] = useState({ state: "", specialty: "", status: "", source: "", minScore: "" });

  const states = useMemo(
    () => Array.from(new Set(leads.map((l) => l.state).filter(Boolean))).sort() as string[],
    [leads],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return leads.filter((l) => {
      if (q && !`${l.practice_name} ${l.contact_name ?? ""} ${l.email ?? ""} ${l.city ?? ""} ${l.state ?? ""}`.toLowerCase().includes(q)) return false;
      if (filters.state && l.state !== filters.state) return false;
      if (filters.specialty && l.specialty !== filters.specialty) return false;
      if (filters.status && l.status !== filters.status) return false;
      if (filters.source && l.source !== filters.source) return false;
      if (filters.minScore && l.score < Number(filters.minScore)) return false;
      return true;
    });
  }, [leads, query, filters]);

  const activeFilters = Object.values(filters).filter(Boolean).length;

  return (
    <Layout title="Lead Management">
      <div className="mb-3.5 flex flex-wrap items-center gap-2.5">
        <div className="relative min-w-[160px] flex-1 sm:max-w-[360px]">
          <Search size={16} className="absolute left-3 top-[11px]" style={{ color: "var(--sub)" }} />
          <input className="input pl-9" placeholder="Search practices, contacts, cities…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <button
          className="btn rounded-[10px] px-3.5 py-[9px] text-sm"
          style={{ background: showFilters ? "var(--accent)22" : "var(--input-bg)", color: showFilters ? "var(--accent)" : "var(--text)", border: "1px solid var(--border)" }}
          onClick={() => setShowFilters((s) => !s)}
        >
          <Filter size={15} /> Filters {activeFilters > 0 && <span className="chip" style={{ background: "var(--accent)", color: "#04121a" }}>{activeFilters}</span>}
        </button>
        <div className="ml-auto flex gap-2">
          <button className="btn rounded-[10px] px-3 py-[9px] text-sm" style={{ background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" }} onClick={() => downloadCsv(filtered)}>
            <Download size={15} /> CSV
          </button>
          <button className="btn rounded-[10px] px-4 py-2.5 text-sm font-bold" style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))", color: "#04121a" }} onClick={() => setEditing("new")}>
            <Plus size={16} /> Add Lead
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="card mb-3.5 grid grid-cols-2 gap-3 p-4 sm:grid-cols-3 lg:grid-cols-5">
          <Sel label="State" value={filters.state} onChange={(v) => setFilters((f) => ({ ...f, state: v }))} options={states} />
          <Sel label="Specialty" value={filters.specialty} onChange={(v) => setFilters((f) => ({ ...f, specialty: v }))} options={[...SPECIALTIES]} />
          <Sel label="Status" value={filters.status} onChange={(v) => setFilters((f) => ({ ...f, status: v }))} options={[...LEAD_STATUSES]} />
          <Sel label="Source" value={filters.source} onChange={(v) => setFilters((f) => ({ ...f, source: v }))} options={[...LEAD_SOURCES]} />
          <div>
            <label className="text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>Min Score</label>
            <input className="input" type="number" value={filters.minScore} onChange={(e) => setFilters((f) => ({ ...f, minScore: e.target.value }))} placeholder="any" />
          </div>
        </div>
      )}

      <div className="mb-2 text-sm" style={{ color: "var(--sub)" }}>{filtered.length} of {leads.length} leads</div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse text-[13.5px]">
            <thead>
              <tr className="text-left text-[11.5px] uppercase tracking-wide" style={{ color: "var(--sub)" }}>
                {["Practice", "Contact", "Location", "Score", "Source", "Status", "Next Follow-Up", ""].map((h) => (
                  <th key={h} className="px-3.5 py-3 font-bold" style={{ borderBottom: "1px solid var(--border)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr><td colSpan={8} className="p-10 text-center" style={{ color: "var(--sub)" }}>Loading…</td></tr>
              )}
              {!loading && filtered.map((l) => {
                const days = daysUntil(l.next_followup_date);
                return (
                  <tr key={l.id} className="row-hover">
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <div className="font-bold">{l.practice_name}</div>
                      <div className="text-[11.5px]" style={{ color: "var(--sub)" }}>{l.specialty} · {l.num_locations} loc</div>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <div className="font-semibold">{l.contact_name ?? "—"}</div>
                      <div className="text-[11.5px]" style={{ color: "var(--sub)" }}>{l.job_title ?? ""}</div>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)", color: "var(--sub)" }}>{[l.city, l.state].filter(Boolean).join(", ") || "—"}</td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="chip" style={{ background: `${scoreColor(l.score)}22`, color: scoreColor(l.score) }}>{l.score}</span>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="inline-flex items-center gap-1.5 text-[12.5px]">
                        <span className="h-2 w-2 rounded" style={{ background: SOURCE_COLORS[l.source] }} />{l.source}
                      </span>
                    </td>
                    <td className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                      <span className="chip" style={{ background: `${STAGE_COLORS[l.status]}22`, color: STAGE_COLORS[l.status] }}>{l.status}</span>
                    </td>
                    <td className="px-3.5 py-3 text-[12.5px]" style={{ borderBottom: "1px solid var(--border)", color: "var(--sub)" }}>
                      {l.next_followup_date ? (
                        <span style={{ color: days !== null && days < 0 ? "#f87171" : days === 0 ? "#fbbf24" : "var(--sub)", fontWeight: days !== null && days <= 0 ? 700 : 400 }}>
                          {days !== null && days < 0 ? `${-days}d overdue` : days === 0 ? "Today" : formatDate(l.next_followup_date)}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-3.5 py-3 text-right" style={{ borderBottom: "1px solid var(--border)" }}>
                      <button className="btn p-1.5" style={{ background: "transparent", color: "var(--sub)" }} onClick={() => setEditing(l)}><Edit3 size={15} /></button>
                      <button
                        className="btn p-1.5"
                        style={{ background: "transparent", color: "#f87171" }}
                        onClick={() => { if (confirm(`Delete ${l.practice_name}?`)) deleteLead(l.id); }}
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={8} className="p-10 text-center" style={{ color: "var(--sub)" }}>No leads match your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <LeadModal
          lead={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSave={(data, id) => {
            if (id) updateLead(id, data);
            else createLead(data);
            setEditing(null);
          }}
        />
      )}
    </Layout>
  );
}

function Sel({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div>
      <label className="text-[11.5px] font-semibold" style={{ color: "var(--sub)" }}>{label}</label>
      <select className="input" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">All</option>
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}
