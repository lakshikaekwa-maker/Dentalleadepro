import { useMemo } from "react";
import { AlertTriangle, Clock, CalendarClock } from "lucide-react";
import Layout from "@/components/Layout";
import { useLeads } from "@/lib/useLeads";
import { formatDate, daysUntil } from "@/lib/utils";
import { STAGE_COLORS, type Lead } from "@/lib/types";

export default function FollowUpsPage() {
  const { leads, loading } = useLeads();

  const buckets = useMemo(() => {
    const withFu = leads.filter((l) => l.next_followup_date).sort((a, b) => (a.next_followup_date ?? "").localeCompare(b.next_followup_date ?? ""));
    return {
      overdue: withFu.filter((l) => (daysUntil(l.next_followup_date) ?? 1) < 0),
      today: withFu.filter((l) => daysUntil(l.next_followup_date) === 0),
      upcoming: withFu.filter((l) => (daysUntil(l.next_followup_date) ?? -1) > 0),
      total: withFu.length,
    };
  }, [leads]);

  const cards: Array<[string, Lead[], string, typeof Clock]> = [
    ["Overdue", buckets.overdue, "#f87171", AlertTriangle],
    ["Due Today", buckets.today, "#fbbf24", Clock],
    ["Upcoming", buckets.upcoming, "var(--accent)", CalendarClock],
  ];

  return (
    <Layout title="Follow-Up Management">
      {loading ? (
        <div className="grid h-64 place-items-center text-sm" style={{ color: "var(--sub)" }}>Loading…</div>
      ) : (
        <>
          <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {cards.map(([label, list, color, Icon]) => (
              <div key={label} className="card flex items-center gap-3.5 p-4">
                <div className="grid h-[38px] w-[38px] place-items-center rounded-[11px]" style={{ background: `${color}22` }}>
                  <Icon size={19} color={color} />
                </div>
                <div>
                  <div className="text-2xl font-extrabold">{list.length}</div>
                  <div className="text-xs font-semibold" style={{ color: "var(--sub)" }}>{label}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-5">
            {cards.map(([label, list, color]) =>
              list.length > 0 ? (
                <div key={label}>
                  <div className="mb-2 flex items-center gap-1.5 text-[13px] font-bold" style={{ color }}>
                    <span className="h-2 w-2 rounded" style={{ background: color }} />{label} ({list.length})
                  </div>
                  <div className="card overflow-hidden">
                    {list.map((l, i) => {
                      const days = daysUntil(l.next_followup_date);
                      return (
                        <div key={l.id} className="row-hover flex items-center gap-3.5 px-4 py-3" style={{ borderBottom: i < list.length - 1 ? "1px solid var(--border)" : "none" }}>
                          <div className="flex-1">
                            <div className="text-[13.5px] font-bold">{l.practice_name}</div>
                            <div className="text-xs" style={{ color: "var(--sub)" }}>{l.contact_name ?? "—"} · {l.job_title ?? ""}</div>
                          </div>
                          <span className="chip" style={{ background: `${STAGE_COLORS[l.status]}22`, color: STAGE_COLORS[l.status] }}>{l.status}</span>
                          <div className="min-w-[96px] text-right text-[12.5px]" style={{ color }}>
                            {days !== null && days < 0 ? `${-days}d overdue` : days === 0 ? "Today" : formatDate(l.next_followup_date)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : null,
            )}
            {buckets.total === 0 && (
              <div className="card p-10 text-center" style={{ color: "var(--sub)" }}>No follow-ups scheduled.</div>
            )}
          </div>
        </>
      )}
    </Layout>
  );
}
