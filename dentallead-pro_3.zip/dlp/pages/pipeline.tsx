import { useState } from "react";
import Layout from "@/components/Layout";
import { useLeads } from "@/lib/useLeads";
import { scoreColor } from "@/lib/utils";
import { LEAD_STATUSES, STAGE_COLORS, type Lead, type LeadStatus } from "@/lib/types";

export default function PipelinePage() {
  const { leads, loading, updateLead } = useLeads();
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<LeadStatus | null>(null);

  const grouped = LEAD_STATUSES.reduce(
    (acc, s) => ({ ...acc, [s]: leads.filter((l) => l.status === s) }),
    {} as Record<LeadStatus, Lead[]>,
  );

  function onDrop(stage: LeadStatus) {
    if (dragId) updateLead(dragId, { status: stage });
    setDragId(null);
    setOverCol(null);
  }

  return (
    <Layout title="Sales Pipeline">
      <p className="mb-4 text-sm" style={{ color: "var(--sub)" }}>
        Drag a card between stages to update its status.
      </p>
      {loading ? (
        <div className="grid h-64 place-items-center text-sm" style={{ color: "var(--sub)" }}>Loading…</div>
      ) : (
        <div className="flex gap-3.5 overflow-x-auto pb-2.5">
          {LEAD_STATUSES.map((stage) => (
            <div
              key={stage}
              onDragOver={(e) => { e.preventDefault(); setOverCol(stage); }}
              onDragLeave={() => setOverCol((o) => (o === stage ? null : o))}
              onDrop={() => onDrop(stage)}
              className="flex w-[248px] flex-shrink-0 flex-col rounded-[14px]"
              style={{
                background: "var(--surface2)",
                border: overCol === stage ? "2px dashed var(--accent)" : "1px solid var(--border)",
                maxHeight: "calc(100vh - 170px)",
              }}
            >
              <div className="flex items-center justify-between px-3.5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2 text-[13.5px] font-bold">
                  <span className="h-[9px] w-[9px] rounded" style={{ background: STAGE_COLORS[stage] }} />{stage}
                </div>
                <span className="chip" style={{ background: "var(--input-bg)", color: "var(--sub)" }}>{grouped[stage].length}</span>
              </div>
              <div className="flex flex-1 flex-col gap-2.5 overflow-y-auto p-2.5">
                {grouped[stage].map((l) => (
                  <div
                    key={l.id}
                    draggable
                    onDragStart={() => setDragId(l.id)}
                    onDragEnd={() => { setDragId(null); setOverCol(null); }}
                    className="card p-3"
                    style={{ borderLeft: `3px solid ${STAGE_COLORS[stage]}`, opacity: dragId === l.id ? 0.4 : 1, cursor: "grab" }}
                  >
                    <div className="text-[13px] font-bold">{l.practice_name}</div>
                    <div className="mt-0.5 text-[11.5px]" style={{ color: "var(--sub)" }}>{l.contact_name ?? "—"}</div>
                    <div className="mt-2.5 flex items-center justify-between">
                      <span className="text-[11px]" style={{ color: "var(--sub)" }}>{[l.city, l.state].filter(Boolean).join(", ")}</span>
                      <span className="chip" style={{ background: `${scoreColor(l.score)}22`, color: scoreColor(l.score) }}>{l.score}</span>
                    </div>
                  </div>
                ))}
                {grouped[stage].length === 0 && (
                  <div className="py-4 text-center text-xs opacity-60" style={{ color: "var(--sub)" }}>Drop leads here</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Layout>
  );
}
