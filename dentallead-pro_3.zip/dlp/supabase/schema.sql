-- ===========================================================================
-- DentalLead Pro — optional Supabase schema.
-- The app works WITHOUT Supabase (it falls back to in-memory sample data).
-- To enable persistence: create a Supabase project, run this in the SQL Editor,
-- then set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.
-- ===========================================================================

create extension if not exists "pgcrypto";

create table if not exists public.leads (
  id                 uuid primary key default gen_random_uuid(),
  practice_name      text not null,
  contact_name       text,
  job_title          text,
  website            text,
  facebook_url       text,
  instagram_url      text,
  linkedin_url       text,
  email              text,
  phone              text,
  state              text,
  city               text,
  num_locations      integer not null default 1,
  num_dentists       integer not null default 1,
  specialty          text,
  source             text not null default 'Other',
  score              integer not null default 50,
  status             text not null default 'New',
  notes              text,
  last_contact_date  date,
  next_followup_date date,
  created_at         timestamptz not null default now()
);

create index if not exists leads_status_idx on public.leads (status);
create index if not exists leads_state_idx  on public.leads (state);

-- This starter is single-tenant (no auth). For a public demo you can allow
-- anonymous read/write. TIGHTEN THIS before storing real data.
alter table public.leads enable row level security;

drop policy if exists "public access" on public.leads;
create policy "public access" on public.leads
  for all using (true) with check (true);
