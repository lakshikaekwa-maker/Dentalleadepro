export const LEAD_STATUSES = [
  "New",
  "Contacted",
  "Meeting Scheduled",
  "Proposal Sent",
  "Negotiation",
  "Won",
  "Lost",
] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const LEAD_SOURCES = [
  "Facebook",
  "Instagram",
  "LinkedIn",
  "Google Search",
  "Referral",
  "Website",
  "Discovery",
  "Other",
] as const;
export type LeadSource = (typeof LEAD_SOURCES)[number];

export const SPECIALTIES = [
  "General Dentistry",
  "Orthodontics",
  "Pediatric Dentistry",
  "Periodontics",
  "Endodontics",
  "Oral Surgery",
  "Prosthodontics",
  "Cosmetic Dentistry",
] as const;
export type Specialty = (typeof SPECIALTIES)[number];

export interface Lead {
  id: string;
  practice_name: string;
  contact_name: string | null;
  job_title: string | null;
  website: string | null;
  facebook_url: string | null;
  instagram_url: string | null;
  linkedin_url: string | null;
  email: string | null;
  phone: string | null;
  state: string | null;
  city: string | null;
  num_locations: number;
  num_dentists: number;
  specialty: Specialty | null;
  source: LeadSource;
  score: number;
  status: LeadStatus;
  notes: string | null;
  last_contact_date: string | null;
  next_followup_date: string | null;
  created_at?: string;
}

export type LeadInput = Omit<Lead, "id" | "created_at">;

export const STAGE_COLORS: Record<LeadStatus, string> = {
  New: "#60a5fa",
  Contacted: "#a78bfa",
  "Meeting Scheduled": "#22d3ee",
  "Proposal Sent": "#fbbf24",
  Negotiation: "#fb923c",
  Won: "#34d399",
  Lost: "#f87171",
};

export const SOURCE_COLORS: Record<LeadSource, string> = {
  Facebook: "#1877f2",
  Instagram: "#e1306c",
  LinkedIn: "#0a66c2",
  "Google Search": "#ea4335",
  Referral: "#10b981",
  Website: "#8b5cf6",
  Discovery: "#22d3ee",
  Other: "#94a3b8",
};
