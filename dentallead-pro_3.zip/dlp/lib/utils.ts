import type { Lead } from "./types";

export function scoreColor(score: number): string {
  if (score >= 80) return "#34d399";
  if (score >= 60) return "#fbbf24";
  if (score >= 40) return "#fb923c";
  return "#f87171";
}

export function computeScore(
  l: Pick<
    Lead,
    | "num_locations"
    | "num_dentists"
    | "website"
    | "facebook_url"
    | "instagram_url"
    | "linkedin_url"
    | "email"
    | "phone"
  >,
): number {
  let s = 30;
  s += Math.min(l.num_locations ?? 1, 5) * 7;
  s += Math.min(l.num_dentists ?? 1, 12);
  if (l.website) s += 8;
  if (l.facebook_url) s += 5;
  if (l.instagram_url) s += 5;
  if (l.linkedin_url) s += 7;
  if (l.email) s += 6;
  if (l.phone) s += 4;
  return Math.max(20, Math.min(99, Math.round(s)));
}

export function formatDate(d: string | null | undefined): string {
  if (!d) return "—";
  const date = new Date(d.includes("T") ? d : `${d}T00:00:00`);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function daysUntil(d: string | null | undefined): number | null {
  if (!d) return null;
  const target = new Date(d.includes("T") ? d : `${d}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / 86_400_000);
}

export function dedupeKey(l: Pick<Lead, "email" | "practice_name">): string {
  return (
    (l.email ?? "").toLowerCase() ||
    l.practice_name.toLowerCase().replace(/[^a-z0-9]/g, "")
  );
}

export function cn(...c: Array<string | false | null | undefined>): string {
  return c.filter(Boolean).join(" ");
}

export function leadsToCsv(leads: Lead[]): string {
  const cols: (keyof Lead)[] = [
    "practice_name",
    "contact_name",
    "job_title",
    "email",
    "phone",
    "website",
    "city",
    "state",
    "num_locations",
    "num_dentists",
    "specialty",
    "source",
    "score",
    "status",
    "next_followup_date",
    "notes",
  ];
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = cols.join(",");
  const rows = leads.map((l) => cols.map((c) => esc(l[c])).join(","));
  return [header, ...rows].join("\n");
}

export function downloadCsv(leads: Lead[], filename = "leads.csv") {
  const blob = new Blob([leadsToCsv(leads)], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
