import { useCallback, useEffect, useState } from "react";
import { supabase, hasSupabase } from "./supabaseClient";
import { SAMPLE_LEADS } from "./sampleData";
import type { Lead, LeadInput } from "./types";

/**
 * Single source of truth for lead data. Uses Supabase when configured,
 * otherwise an in-memory copy of the sample data (so the app works with
 * zero backend setup). All mutations update local state immediately.
 */
export function useLeads() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    if (hasSupabase && supabase) {
      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .order("created_at", { ascending: false });
      if (!error && data) {
        setLeads(data as Lead[]);
        setLoading(false);
        return;
      }
    }
    setLeads(SAMPLE_LEADS);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const createLead = useCallback(async (input: LeadInput) => {
    if (hasSupabase && supabase) {
      const { data } = await supabase.from("leads").insert(input).select().single();
      if (data) {
        setLeads((ls) => [data as Lead, ...ls]);
        return;
      }
    }
    const newLead: Lead = { ...input, id: `local-${Date.now()}` };
    setLeads((ls) => [newLead, ...ls]);
  }, []);

  const updateLead = useCallback(async (id: string, input: Partial<LeadInput>) => {
    if (hasSupabase && supabase) {
      await supabase.from("leads").update(input).eq("id", id);
    }
    setLeads((ls) => ls.map((l) => (l.id === id ? { ...l, ...input } : l)));
  }, []);

  const deleteLead = useCallback(async (id: string) => {
    if (hasSupabase && supabase) {
      await supabase.from("leads").delete().eq("id", id);
    }
    setLeads((ls) => ls.filter((l) => l.id !== id));
  }, []);

  return { leads, loading, createLead, updateLead, deleteLead, reload: load };
}
