# DentalLead Pro

A CRM for finding, managing, qualifying, and tracking U.S. dental-practice sales leads.

**Stack:** Next.js 14 (Pages Router) · TypeScript · Tailwind CSS · Supabase (optional).

> Runs with **zero backend setup** — without Supabase configured, it uses 50 built-in
> sample leads so it deploys and renders immediately. Add Supabase to persist data.

## File structure

```
dentallead-pro/
├── components/
│   ├── Layout.tsx          # sidebar + topbar + dark mode
│   └── LeadModal.tsx       # add/edit lead form
├── lib/
│   ├── types.ts            # domain types & constants
│   ├── supabaseClient.ts   # supabase client (optional)
│   ├── useLeads.ts         # data hook (supabase OR sample fallback)
│   ├── sampleData.ts       # 50 sample leads
│   └── utils.ts            # scoring, dates, csv, helpers
├── pages/
│   ├── _app.tsx
│   ├── _document.tsx
│   ├── index.tsx           # Dashboard
│   ├── discovery.tsx       # Lead Discovery
│   ├── leads.tsx           # Lead Management
│   ├── pipeline.tsx        # Kanban (drag & drop)
│   ├── followups.tsx       # Follow-up reminders
│   └── reports.tsx         # Reporting
├── styles/globals.css
├── supabase/schema.sql     # optional database schema
├── public/favicon.svg
├── .env.example
├── netlify.toml
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
└── package.json
```

## Run locally

```bash
npm install
npm run dev          # http://localhost:3000
```

Works immediately on sample data. To persist with Supabase:

```bash
cp .env.example .env.local   # then fill in your Supabase URL + anon key
```

Run `supabase/schema.sql` in your Supabase project's SQL Editor.

## Deploy to Netlify (recommended: Git import)

1. Push this folder to a GitHub repo.
2. Netlify → **Add new site → Import an existing project** → select the repo.
3. Build settings come from `netlify.toml` automatically — **do not** drag-and-drop the
   folder; Netlify must run `npm run build`.
4. (Optional) add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` under
   **Site settings → Environment variables**.
5. Deploy.

### Or via CLI

```bash
npm install -g netlify-cli
netlify login
netlify init
netlify deploy --build --prod
```

The `@netlify/plugin-nextjs` runtime (auto-installed by Netlify) handles SSR/routing, so
all six pages resolve correctly — no more 404s from a missing build step.
